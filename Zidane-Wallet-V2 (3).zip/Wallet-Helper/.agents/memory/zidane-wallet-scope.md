---
name: ZIDANE WALLET V1 scope
description: The user's demo-only boundary for the ZIDANE WALLET V1 product.
---

For ZIDANE WALLET V1, keep all transactions local and simulated. Do not add real Bitcoin functionality or private-key handling yet.

**Why:** The user explicitly set this as the V1 scope.

**How to apply:** Keep send, receive, balance, and history behaviors within the local simulation.

Preserve saved simulated transaction rows during history migration. Merge supported legacy and current history arrays, rekey ID collisions instead of deleting rows, and keep an accurate signed balance if older sends overdraw the sample balance. Reject new sends while that balance is negative.

**Why:** The user explicitly requires history preservation and duplicate-ID repair; discarding overdrawn history would erase transactions.

**How to apply:** When changing wallet persistence or transaction ID logic, preserve all valid records and test collision repair, reload persistence, ordering, and balance recovery.
