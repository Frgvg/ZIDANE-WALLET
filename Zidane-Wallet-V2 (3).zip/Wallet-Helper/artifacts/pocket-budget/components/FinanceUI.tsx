import { Feather } from '@expo/vector-icons';
import React from 'react';
import { ActivityIndicator, Pressable, StyleSheet, Text, View } from 'react-native';
import type { Budget, Transaction } from '@/providers/BudgetProvider';
import { useColors } from '@/hooks/useColors';
import { formatMoney, formatShortDate, getCategory } from '@/lib/finance';

export function ScreenState({
  type,
  message,
  onRetry,
}: {
  type: 'loading' | 'error';
  message?: string | null;
  onRetry?: () => void;
}) {
  const colors = useColors();
  return (
    <View
      style={[
        styles.state,
        { backgroundColor: colors.background, paddingHorizontal: 28 },
      ]}
    >
      {type === 'loading' ? (
        <ActivityIndicator size="large" color={colors.primary} />
      ) : (
        <Feather name="alert-circle" size={30} color={colors.destructive} />
      )}
      <Text style={[styles.stateTitle, { color: colors.foreground }]}>
        {type === 'loading' ? 'Opening your budget' : 'Something went wrong'}
      </Text>
      {type === 'error' ? (
        <>
          <Text style={[styles.stateText, { color: colors.mutedForeground }]}>
            {message ?? 'Please try again.'}
          </Text>
          {onRetry ? (
            <Pressable
              accessibilityRole="button"
              onPress={onRetry}
              style={({ pressed }) => [
                styles.retryButton,
                { backgroundColor: colors.primary, opacity: pressed ? 0.82 : 1 },
              ]}
            >
              <Text style={[styles.retryText, { color: colors.primaryForeground }]}>
                Try again
              </Text>
            </Pressable>
          ) : null}
        </>
      ) : null}
    </View>
  );
}

export function CategoryGlyph({
  category,
  size = 18,
  color,
}: {
  category: string;
  size?: number;
  color: string;
}) {
  const item = getCategory(category);
  return <Feather name={item.icon} size={size} color={color} />;
}

export function CategoryChip({
  category,
  selected,
  onPress,
  disabled,
}: {
  category: { id: string; label: string };
  selected: boolean;
  onPress: () => void;
  disabled?: boolean;
}) {
  const colors = useColors();
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ selected, disabled: !!disabled }}
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => [
        styles.categoryChip,
        {
          backgroundColor: selected ? colors.accent : colors.card,
          borderColor: selected ? colors.accent : colors.border,
          opacity: disabled ? 0.45 : pressed ? 0.75 : 1,
        },
      ]}
    >
      <Text
        style={[
          styles.categoryChipText,
          { color: selected ? colors.accentForeground : colors.foreground },
        ]}
      >
        {category.label}
      </Text>
    </Pressable>
  );
}

export function TransactionRow({
  transaction,
  currency,
  onPress,
}: {
  transaction: Transaction;
  currency: 'XOF';
  onPress: () => void;
}) {
  const colors = useColors();
  const category = getCategory(transaction.category);
  const isIncome = transaction.type === 'income';
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={`Edit ${category.label}, ${formatMoney(transaction.amount, currency)}`}
      onPress={onPress}
      style={({ pressed }) => [
        styles.transactionRow,
        { borderBottomColor: colors.border, opacity: pressed ? 0.72 : 1 },
      ]}
    >
      <View style={[styles.categoryIcon, { backgroundColor: colors.secondary }]}>
        <CategoryGlyph category={transaction.category} color={colors.primary} />
      </View>
      <View style={styles.transactionInfo}>
        <Text numberOfLines={1} style={[styles.transactionName, { color: colors.foreground }]}>
          {transaction.note || category.label}
        </Text>
        <Text style={[styles.transactionMeta, { color: colors.mutedForeground }]}>
          {category.label} · {formatShortDate(transaction.date)}
        </Text>
      </View>
      <Text
        style={[
          styles.transactionAmount,
          { color: isIncome ? colors.primary : colors.foreground },
        ]}
      >
        {isIncome ? '+' : '−'}
        {formatMoney(transaction.amount, currency)}
      </Text>
    </Pressable>
  );
}

export function BudgetProgress({
  budget,
  spent,
  currency,
  compact = false,
}: {
  budget: Budget;
  spent: number;
  currency: 'XOF';
  compact?: boolean;
}) {
  const colors = useColors();
  const category = getCategory(budget.category);
  const ratio = budget.limit > 0 ? spent / budget.limit : 0;
  const progress = Math.min(ratio, 1);
  const over = ratio >= 1;
  return (
    <View style={[styles.budgetProgress, compact && styles.budgetProgressCompact]}>
      <View style={styles.budgetHeading}>
        <View style={styles.budgetName}>
          <View style={[styles.categoryIcon, styles.smallCategoryIcon, { backgroundColor: colors.secondary }]}>
            <CategoryGlyph category={budget.category} size={16} color={colors.primary} />
          </View>
          <Text style={[styles.budgetCategory, { color: colors.foreground }]}>
            {category.label}
          </Text>
        </View>
        <Text style={[styles.budgetAmounts, { color: colors.mutedForeground }]}>
          <Text style={{ color: over ? colors.destructive : colors.foreground }}>
            {formatMoney(spent, currency)}
          </Text>
          {'  /  '}
          {formatMoney(budget.limit, currency)}
        </Text>
      </View>
      <View style={[styles.progressTrack, { backgroundColor: colors.secondary }]}>
        <View
          style={[
            styles.progressFill,
            {
              width: `${progress * 100}%`,
              backgroundColor: over ? colors.destructive : colors.primary,
            },
          ]}
        />
      </View>
      {!compact ? (
        <Text style={[styles.remaining, { color: over ? colors.destructive : colors.mutedForeground }]}>
          {over
            ? `${formatMoney(spent - budget.limit, currency)} over your limit`
            : `${formatMoney(budget.limit - spent, currency)} left this month`}
        </Text>
      ) : null}
    </View>
  );
}

export function EmptyPanel({
  icon,
  title,
  description,
  action,
}: {
  icon: keyof typeof Feather.glyphMap;
  title: string;
  description: string;
  action?: React.ReactNode;
}) {
  const colors = useColors();
  return (
    <View style={[styles.emptyPanel, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <View style={[styles.emptyIcon, { backgroundColor: colors.secondary }]}>
        <Feather name={icon} size={22} color={colors.primary} />
      </View>
      <Text style={[styles.emptyTitle, { color: colors.foreground }]}>{title}</Text>
      <Text style={[styles.emptyDescription, { color: colors.mutedForeground }]}>
        {description}
      </Text>
      {action}
    </View>
  );
}

export function SectionHeading({
  title,
  action,
  onAction,
}: {
  title: string;
  action?: string;
  onAction?: () => void;
}) {
  const colors = useColors();
  return (
    <View style={styles.sectionHeading}>
      <Text style={[styles.sectionTitle, { color: colors.foreground }]}>{title}</Text>
      {action && onAction ? (
        <Pressable accessibilityRole="button" onPress={onAction} hitSlop={8}>
          <Text style={[styles.sectionAction, { color: colors.primary }]}>{action}</Text>
        </Pressable>
      ) : null}
    </View>
  );
}

export function IconButton({
  icon,
  label,
  onPress,
}: {
  icon: keyof typeof Feather.glyphMap;
  label: string;
  onPress: () => void;
}) {
  const colors = useColors();
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={label}
      onPress={onPress}
      hitSlop={8}
      style={({ pressed }) => [
        styles.iconButton,
        { backgroundColor: colors.card, borderColor: colors.border, opacity: pressed ? 0.7 : 1 },
      ]}
    >
      <Feather name={icon} size={19} color={colors.foreground} />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  state: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
  },
  stateTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 18, textAlign: 'center' },
  stateText: { fontFamily: 'Inter_400Regular', fontSize: 14, textAlign: 'center', lineHeight: 21 },
  retryButton: { paddingHorizontal: 20, paddingVertical: 12, borderRadius: 14, marginTop: 6 },
  retryText: { fontFamily: 'Inter_600SemiBold', fontSize: 14 },
  categoryChip: {
    borderWidth: 1,
    borderRadius: 999,
    paddingHorizontal: 14,
    paddingVertical: 10,
    marginRight: 8,
    marginBottom: 8,
  },
  categoryChipText: { fontFamily: 'Inter_500Medium', fontSize: 13 },
  transactionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 13,
    borderBottomWidth: StyleSheet.hairlineWidth,
    gap: 12,
  },
  categoryIcon: {
    width: 42,
    height: 42,
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'center',
  },
  smallCategoryIcon: { width: 32, height: 32, borderRadius: 12 },
  transactionInfo: { flex: 1, minWidth: 0, gap: 4 },
  transactionName: { fontFamily: 'Inter_600SemiBold', fontSize: 14 },
  transactionMeta: { fontFamily: 'Inter_400Regular', fontSize: 12 },
  transactionAmount: { fontFamily: 'Inter_600SemiBold', fontSize: 14 },
  budgetProgress: { gap: 10, paddingVertical: 15 },
  budgetProgressCompact: { paddingVertical: 10 },
  budgetHeading: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', gap: 8 },
  budgetName: { flexDirection: 'row', alignItems: 'center', gap: 10, flexShrink: 1 },
  budgetCategory: { fontFamily: 'Inter_600SemiBold', fontSize: 14 },
  budgetAmounts: { fontFamily: 'Inter_400Regular', fontSize: 11, textAlign: 'right' },
  progressTrack: { height: 7, borderRadius: 99, overflow: 'hidden' },
  progressFill: { height: '100%', borderRadius: 99 },
  remaining: { fontFamily: 'Inter_400Regular', fontSize: 11 },
  emptyPanel: {
    borderWidth: 1,
    borderRadius: 22,
    padding: 22,
    alignItems: 'center',
    gap: 10,
  },
  emptyIcon: { width: 50, height: 50, borderRadius: 18, alignItems: 'center', justifyContent: 'center', marginBottom: 2 },
  emptyTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 16, textAlign: 'center' },
  emptyDescription: { fontFamily: 'Inter_400Regular', fontSize: 13, lineHeight: 20, textAlign: 'center' },
  sectionHeading: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  sectionTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 18 },
  sectionAction: { fontFamily: 'Inter_600SemiBold', fontSize: 13 },
  iconButton: {
    width: 44,
    height: 44,
    borderRadius: 16,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
