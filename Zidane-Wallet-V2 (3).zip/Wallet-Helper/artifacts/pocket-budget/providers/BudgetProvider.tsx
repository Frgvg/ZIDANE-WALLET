import AsyncStorage from '@react-native-async-storage/async-storage';
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react';
import type { CategoryId, CurrencyCode, TransactionType } from '@/lib/finance';
import { createId } from '@/lib/finance';

const STORAGE_KEY = 'pocket-budget-data-v1';

export interface Transaction {
  id: string;
  amount: number;
  type: TransactionType;
  category: CategoryId;
  note: string;
  date: string;
}

export interface Budget {
  id: string;
  category: CategoryId;
  limit: number;
}

export interface BudgetData {
  transactions: Transaction[];
  budgets: Budget[];
  currency: CurrencyCode;
}

export type TransactionDraft = Omit<Transaction, 'id'> & { id?: string };
export type BudgetDraft = Omit<Budget, 'id'> & { id?: string };

interface BudgetContextValue extends BudgetData {
  isHydrated: boolean;
  storageError: string | null;
  reload: () => Promise<void>;
  saveTransaction: (draft: TransactionDraft) => Promise<void>;
  removeTransaction: (id: string) => Promise<void>;
  saveBudget: (draft: BudgetDraft) => Promise<void>;
  removeBudget: (id: string) => Promise<void>;
}

const initialData: BudgetData = {
  transactions: [],
  budgets: [],
  currency: 'XOF',
};

const BudgetContext = createContext<BudgetContextValue | null>(null);

function parseStoredData(raw: string | null): BudgetData {
  if (!raw) return initialData;
  const parsed: unknown = JSON.parse(raw);
  if (!parsed || typeof parsed !== 'object') {
    throw new Error('Saved budget data has an unexpected format.');
  }
  const value = parsed as Partial<BudgetData>;
  return {
    transactions: Array.isArray(value.transactions) ? value.transactions : [],
    budgets: Array.isArray(value.budgets) ? value.budgets : [],
    currency: value.currency === 'XOF' ? value.currency : 'XOF',
  };
}

export function BudgetProvider({ children }: { children: React.ReactNode }) {
  const [data, setData] = useState<BudgetData>(initialData);
  const [isHydrated, setIsHydrated] = useState(false);
  const [storageError, setStorageError] = useState<string | null>(null);

  const reload = useCallback(async () => {
    setStorageError(null);
    setIsHydrated(false);
    try {
      const raw = await AsyncStorage.getItem(STORAGE_KEY);
      setData(parseStoredData(raw));
      setIsHydrated(true);
    } catch {
      setStorageError('Your saved budget could not be opened. Your data has not been changed.');
      setIsHydrated(true);
    }
  }, []);

  useEffect(() => {
    void reload();
  }, [reload]);

  const persist = useCallback(async (next: BudgetData) => {
    try {
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      setData(next);
      setStorageError(null);
    } catch {
      const message = 'Your change could not be saved on this device. Please try again.';
      setStorageError(message);
      throw new Error(message);
    }
  }, []);

  const saveTransaction = useCallback(
    async (draft: TransactionDraft) => {
      if (!Number.isFinite(draft.amount) || draft.amount <= 0) {
        throw new Error('Enter an amount greater than zero.');
      }
      const transaction: Transaction = {
        ...draft,
        id: draft.id ?? createId(),
        note: draft.note.trim(),
      };
      const transactions = data.transactions.some((item) => item.id === transaction.id)
        ? data.transactions.map((item) => (item.id === transaction.id ? transaction : item))
        : [transaction, ...data.transactions];
      await persist({ ...data, transactions });
    },
    [data, persist],
  );

  const removeTransaction = useCallback(
    async (id: string) => {
      await persist({
        ...data,
        transactions: data.transactions.filter((item) => item.id !== id),
      });
    },
    [data, persist],
  );

  const saveBudget = useCallback(
    async (draft: BudgetDraft) => {
      if (!Number.isFinite(draft.limit) || draft.limit <= 0) {
        throw new Error('Enter a monthly limit greater than zero.');
      }
      if (
        data.budgets.some(
          (budget) => budget.category === draft.category && budget.id !== draft.id,
        )
      ) {
        throw new Error('You already have a budget for that category.');
      }
      const budget: Budget = { ...draft, id: draft.id ?? createId() };
      const budgets = data.budgets.some((item) => item.id === budget.id)
        ? data.budgets.map((item) => (item.id === budget.id ? budget : item))
        : [...data.budgets, budget];
      await persist({ ...data, budgets });
    },
    [data, persist],
  );

  const removeBudget = useCallback(
    async (id: string) => {
      await persist({
        ...data,
        budgets: data.budgets.filter((item) => item.id !== id),
      });
    },
    [data, persist],
  );

  const value = useMemo(
    () => ({
      ...data,
      isHydrated,
      storageError,
      reload,
      saveTransaction,
      removeTransaction,
      saveBudget,
      removeBudget,
    }),
    [
      data,
      isHydrated,
      storageError,
      reload,
      saveTransaction,
      removeTransaction,
      saveBudget,
      removeBudget,
    ],
  );

  return <BudgetContext.Provider value={value}>{children}</BudgetContext.Provider>;
}

export function useBudget(): BudgetContextValue {
  const value = useContext(BudgetContext);
  if (!value) throw new Error('useBudget must be used inside BudgetProvider.');
  return value;
}
