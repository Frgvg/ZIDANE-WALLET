import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { router, useLocalSearchParams } from 'expo-router';
import React, { useMemo, useState } from 'react';
import {
  Alert,
  Keyboard,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { CategoryChip, ScreenState } from '@/components/FinanceUI';
import { useColors } from '@/hooks/useColors';
import { getCategories, type CategoryId, type TransactionType } from '@/lib/finance';
import { useBudget } from '@/providers/BudgetProvider';

export default function AddTransactionScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id?: string }>();
  const {
    transactions,
    isHydrated,
    storageError,
    reload,
    saveTransaction,
    removeTransaction,
  } = useBudget();
  const transaction = id ? transactions.find((item) => item.id === id) : undefined;

  const [type, setType] = useState<TransactionType>(() => transaction?.type ?? 'expense');
  const [category, setCategory] = useState<CategoryId>(
    () => transaction?.category ?? getCategories('expense')[0].id,
  );
  const [amount, setAmount] = useState(() => (transaction ? String(transaction.amount) : ''));
  const [note, setNote] = useState(() => transaction?.note ?? '');
  const [saving, setSaving] = useState(false);
  const categories = useMemo(() => getCategories(type), [type]);
  const selectedCategory = categories.some((item) => item.id === category)
    ? category
    : categories[0].id;

  if (!isHydrated) return <ScreenState type="loading" />;
  if (storageError) {
    return <ScreenState type="error" message={storageError} onRetry={() => void reload()} />;
  }
  if (id && !transaction) {
    return <ScreenState type="error" message="This transaction could not be found." onRetry={() => router.back()} />;
  }

  const topInset = Platform.OS === 'web' ? 67 : insets.top;
  const bottomInset = Platform.OS === 'web' ? 34 : insets.bottom;
  const parsedAmount = Number(amount.replace(',', '.'));
  const canSave = Number.isFinite(parsedAmount) && parsedAmount > 0 && !saving;

  const submit = async () => {
    if (!canSave) return;
    setSaving(true);
    try {
      await saveTransaction({
        id: transaction?.id,
        type,
        category: selectedCategory,
        amount: parsedAmount,
        note,
        date: transaction?.date ?? new Date().toISOString(),
      });
      void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      router.back();
    } catch (error) {
      Alert.alert('Could not save', error instanceof Error ? error.message : 'Please try again.');
    } finally {
      setSaving(false);
    }
  };

  const confirmDelete = () => {
    if (!transaction) return;
    Alert.alert(
      'Delete this entry?',
      'This will remove it from your activity and budget totals.',
      [
        { text: 'Keep it', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: () => {
            void removeTransaction(transaction.id)
              .then(() => router.back())
              .catch((error: unknown) => {
                Alert.alert('Could not delete', error instanceof Error ? error.message : 'Please try again.');
              });
          },
        },
      ],
    );
  };

  const content = (
    <>
      <View style={styles.topBar}>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Close"
          onPress={() => router.back()}
          hitSlop={10}
          style={[styles.closeButton, { backgroundColor: colors.secondary }]}
        >
          <Feather name="x" size={19} color={colors.foreground} />
        </Pressable>
        <Text style={[styles.screenTitle, { color: colors.foreground }]}>
          {transaction ? 'Edit entry' : 'New entry'}
        </Text>
        <View style={{ width: 42 }} />
      </View>

      <Text style={[styles.eyebrow, { color: colors.mutedForeground }]}>WHAT DID YOU {type === 'expense' ? 'SPEND' : 'RECEIVE'}?</Text>
      <View style={[styles.amountCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <TextInput
          accessibilityLabel="Amount in XOF"
          testID="transaction-amount"
          value={amount}
          onChangeText={(value) =>
            setAmount(value.replace(/[^0-9.,]/g, '').replace(/([.,].*)[.,]/g, '$1'))
          }
          keyboardType="decimal-pad"
          placeholder="0"
          placeholderTextColor={colors.mutedForeground}
          style={[styles.amountInput, { color: colors.foreground }]}
          autoFocus={!transaction}
        />
        <Text style={[styles.amountCurrency, { color: colors.mutedForeground }]}>FCFA</Text>
      </View>

      <View style={[styles.typeSwitch, { backgroundColor: colors.secondary }]}>
        {(['expense', 'income'] as const).map((item) => {
          const active = item === type;
          return (
            <Pressable
              accessibilityRole="button"
              accessibilityState={{ selected: active }}
              key={item}
              onPress={() => {
                setType(item);
                setCategory(getCategories(item)[0].id);
              }}
              style={[
                styles.typeOption,
                active && { backgroundColor: colors.card },
              ]}
            >
              <Text style={[styles.typeText, { color: active ? colors.foreground : colors.mutedForeground }]}>
                {item === 'expense' ? 'Expense' : 'Income'}
              </Text>
            </Pressable>
          );
        })}
      </View>

      <View style={styles.fieldGroup}>
        <Text style={[styles.fieldLabel, { color: colors.foreground }]}>Category</Text>
        <View style={styles.categoryGrid}>
          {categories.map((item) => (
            <CategoryChip
              key={item.id}
              category={item}
              selected={selectedCategory === item.id}
              onPress={() => setCategory(item.id)}
            />
          ))}
        </View>
      </View>

      <View style={styles.fieldGroup}>
        <Text style={[styles.fieldLabel, { color: colors.foreground }]}>Note <Text style={{ color: colors.mutedForeground, fontFamily: 'Inter_400Regular' }}>· optional</Text></Text>
        <TextInput
          accessibilityLabel="Optional note"
          testID="transaction-note"
          value={note}
          onChangeText={setNote}
          placeholder={type === 'expense' ? 'What was it for?' : 'Where did it come from?'}
          placeholderTextColor={colors.mutedForeground}
          style={[styles.noteInput, { backgroundColor: colors.card, borderColor: colors.border, color: colors.foreground }]}
          returnKeyType="done"
          onSubmitEditing={Keyboard.dismiss}
          maxLength={70}
        />
      </View>

      <Pressable
        accessibilityRole="button"
        accessibilityState={{ disabled: !canSave }}
        testID="save-transaction"
        disabled={!canSave}
        onPress={() => void submit()}
        style={({ pressed }) => [
          styles.saveButton,
          { backgroundColor: colors.primary, opacity: !canSave ? 0.45 : pressed ? 0.82 : 1 },
        ]}
      >
        <Text style={[styles.saveButtonText, { color: colors.primaryForeground }]}>
          {saving ? 'Saving…' : transaction ? 'Save changes' : 'Add entry'}
        </Text>
        <Feather name="arrow-right" size={18} color={colors.primaryForeground} />
      </Pressable>

      {transaction ? (
        <Pressable accessibilityRole="button" onPress={confirmDelete} style={styles.deleteButton}>
          <Feather name="trash-2" size={16} color={colors.destructive} />
          <Text style={[styles.deleteText, { color: colors.destructive }]}>Delete entry</Text>
        </Pressable>
      ) : null}
    </>
  );

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <KeyboardAwareScrollViewCompat
        style={{ flex: 1 }}
        contentContainerStyle={[
          styles.content,
          { paddingTop: topInset + 10, paddingBottom: bottomInset + 24 },
        ]}
        bottomOffset={24}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        {content}
      </KeyboardAwareScrollViewCompat>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  content: { paddingHorizontal: 22, gap: 19 },
  topBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 3 },
  closeButton: { width: 42, height: 42, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  screenTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 17 },
  eyebrow: { fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 1.15, marginBottom: -10 },
  amountCard: { minHeight: 94, borderWidth: 1, borderRadius: 22, paddingHorizontal: 19, flexDirection: 'row', alignItems: 'center' },
  amountInput: { flex: 1, minWidth: 0, fontFamily: 'Inter_700Bold', fontSize: 38, letterSpacing: -1 },
  amountCurrency: { fontFamily: 'Inter_600SemiBold', fontSize: 12, marginLeft: 8 },
  typeSwitch: { borderRadius: 15, padding: 4, flexDirection: 'row' },
  typeOption: { flex: 1, alignItems: 'center', justifyContent: 'center', borderRadius: 12, minHeight: 42 },
  typeText: { fontFamily: 'Inter_600SemiBold', fontSize: 13 },
  fieldGroup: { gap: 10 },
  fieldLabel: { fontFamily: 'Inter_600SemiBold', fontSize: 14 },
  categoryGrid: { flexDirection: 'row', flexWrap: 'wrap', marginRight: -8 },
  noteInput: { minHeight: 50, borderRadius: 15, borderWidth: 1, paddingHorizontal: 15, fontFamily: 'Inter_400Regular', fontSize: 14 },
  saveButton: { minHeight: 54, borderRadius: 17, paddingHorizontal: 18, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 3 },
  saveButtonText: { fontFamily: 'Inter_600SemiBold', fontSize: 15 },
  deleteButton: { minHeight: 42, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8 },
  deleteText: { fontFamily: 'Inter_600SemiBold', fontSize: 13 },
});
