import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import React from 'react';
import { Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { BudgetProgress, EmptyPanel, IconButton, ScreenState, SectionHeading, TransactionRow } from '@/components/FinanceUI';
import { useColors } from '@/hooks/useColors';
import { formatMoney, isInCurrentMonth, monthLabel } from '@/lib/finance';
import { useBudget } from '@/providers/BudgetProvider';

export default function OverviewScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const {
    transactions,
    budgets,
    currency,
    isHydrated,
    storageError,
    reload,
  } = useBudget();

  if (!isHydrated) return <ScreenState type="loading" />;
  if (storageError) {
    return <ScreenState type="error" message={storageError} onRetry={() => void reload()} />;
  }

  const monthTransactions = transactions.filter((item) => isInCurrentMonth(item.date));
  const expenses = monthTransactions
    .filter((item) => item.type === 'expense')
    .reduce((total, item) => total + item.amount, 0);
  const income = monthTransactions
    .filter((item) => item.type === 'income')
    .reduce((total, item) => total + item.amount, 0);
  const recentTransactions = [...transactions]
    .sort((a, b) => b.date.localeCompare(a.date))
    .slice(0, 4);
  const categorySpending = new Map<string, number>();
  for (const transaction of monthTransactions) {
    if (transaction.type === 'expense') {
      categorySpending.set(
        transaction.category,
        (categorySpending.get(transaction.category) ?? 0) + transaction.amount,
      );
    }
  }
  const topBudgets = budgets.slice(0, 2);
  const topInset = Platform.OS === 'web' ? 67 : insets.top;
  const bottomInset = Platform.OS === 'web' ? 34 : insets.bottom;
  const greeting = new Date().getHours() < 12 ? 'Good morning' : new Date().getHours() < 18 ? 'Good afternoon' : 'Good evening';

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: colors.background }}
      contentContainerStyle={[
        styles.content,
        { paddingTop: topInset + 14, paddingBottom: bottomInset + 112 },
      ]}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.topBar}>
        <View>
          <Text style={[styles.eyebrow, { color: colors.primary }]}>POCKET BUDGET</Text>
          <Text style={[styles.greeting, { color: colors.foreground }]}>{greeting}.</Text>
          <Text style={[styles.month, { color: colors.mutedForeground }]}>{monthLabel()}</Text>
        </View>
        <IconButton
          icon="plus"
          label="Add a transaction"
          onPress={() => router.push('/add-transaction')}
        />
      </View>

      <View style={[styles.heroCard, { backgroundColor: colors.primary }]}>
        <View style={styles.heroTop}>
          <View>
            <Text style={[styles.heroLabel, { color: colors.primaryForeground, opacity: 0.78 }]}>
              Spent this month
            </Text>
            <Text style={[styles.heroAmount, { color: colors.primaryForeground }]}>
              {formatMoney(expenses, currency)}
            </Text>
          </View>
          <View style={[styles.currencyBadge, { backgroundColor: colors.accent }]}>
            <Text style={[styles.currencyText, { color: colors.accentForeground }]}>XOF</Text>
          </View>
        </View>
        <View style={[styles.heroRule, { backgroundColor: colors.primaryForeground, opacity: 0.22 }]} />
        <View style={styles.heroFooter}>
          <View style={styles.heroMetric}>
            <View style={[styles.heroMetricIcon, { backgroundColor: colors.secondary }]}>
              <Feather name="arrow-down-left" size={14} color={colors.accentForeground} />
            </View>
            <View>
              <Text style={[styles.heroMetricLabel, { color: colors.primaryForeground, opacity: 0.76 }]}>
                Income
              </Text>
              <Text style={[styles.heroMetricValue, { color: colors.primaryForeground }]}>
                {formatMoney(income, currency)}
              </Text>
            </View>
          </View>
          <View style={styles.heroMetric}>
            <View style={[styles.heroMetricIcon, { backgroundColor: colors.secondary }]}>
              <Feather name="arrow-up-right" size={14} color={colors.destructive} />
            </View>
            <View>
              <Text style={[styles.heroMetricLabel, { color: colors.primaryForeground, opacity: 0.76 }]}>
                Expenses
              </Text>
              <Text style={[styles.heroMetricValue, { color: colors.primaryForeground }]}>
                {formatMoney(expenses, currency)}
              </Text>
            </View>
          </View>
        </View>
        <View style={[styles.heroDecoration, { borderColor: colors.accent, opacity: 0.1 }]} />
      </View>

      <View style={styles.section}>
        <SectionHeading title="Monthly budgets" action="See all" onAction={() => router.push('/(tabs)/budgets')} />
        {topBudgets.length ? (
          <View style={[styles.panel, { backgroundColor: colors.card, borderColor: colors.border }]}>
            {topBudgets.map((budget) => (
              <BudgetProgress
                key={budget.id}
                budget={budget}
                spent={categorySpending.get(budget.category) ?? 0}
                currency={currency}
                compact
              />
            ))}
          </View>
        ) : (
          <EmptyPanel
            icon="target"
            title="Give your money a plan"
            description="Set a monthly limit for a category and see how you’re tracking."
            action={
              <Pressable
                accessibilityRole="button"
                onPress={() => router.push('/add-budget')}
                style={({ pressed }) => [
                  styles.inlineAction,
                  { backgroundColor: colors.accent, opacity: pressed ? 0.78 : 1 },
                ]}
              >
                <Text style={[styles.inlineActionText, { color: colors.accentForeground }]}>Create a budget</Text>
              </Pressable>
            }
          />
        )}
      </View>

      <View style={styles.section}>
        <SectionHeading
          title="Recent activity"
          action={transactions.length > 4 ? 'View all' : undefined}
          onAction={() => router.push('/(tabs)/transactions')}
        />
        {recentTransactions.length ? (
          <View style={[styles.panel, { backgroundColor: colors.card, borderColor: colors.border }]}>
            {recentTransactions.map((transaction) => (
              <TransactionRow
                key={transaction.id}
                transaction={transaction}
                currency={currency}
                onPress={() =>
                  router.push({
                    pathname: '/add-transaction',
                    params: { id: transaction.id },
                  })
                }
              />
            ))}
          </View>
        ) : (
          <EmptyPanel
            icon="activity"
            title="Your story starts here"
            description="Add your first income or expense to see where your money goes."
            action={
              <Pressable
                accessibilityRole="button"
                onPress={() => router.push('/add-transaction')}
                style={({ pressed }) => [
                  styles.inlineAction,
                  { backgroundColor: colors.accent, opacity: pressed ? 0.78 : 1 },
                ]}
              >
                <Text style={[styles.inlineActionText, { color: colors.accentForeground }]}>Add transaction</Text>
              </Pressable>
            }
          />
        )}
      </View>

      <Text style={[styles.privacyNote, { color: colors.mutedForeground }]}>
        Your entries stay on this device. Pocket Budget doesn’t connect to your bank.
      </Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: 20, gap: 22 },
  topBar: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  eyebrow: { fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 1.8, marginBottom: 7 },
  greeting: { fontFamily: 'Inter_700Bold', fontSize: 27, letterSpacing: -0.8 },
  month: { fontFamily: 'Inter_400Regular', fontSize: 13, marginTop: 4 },
  heroCard: {
    borderRadius: 26,
    padding: 22,
    overflow: 'hidden',
    gap: 18,
  },
  heroTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  heroLabel: { fontFamily: 'Inter_500Medium', fontSize: 13, marginBottom: 8 },
  heroAmount: { fontFamily: 'Inter_700Bold', fontSize: 30, letterSpacing: -0.7 },
  currencyBadge: { borderRadius: 99, paddingHorizontal: 11, paddingVertical: 7 },
  currencyText: { fontFamily: 'Inter_600SemiBold', fontSize: 10, letterSpacing: 0.6 },
  heroRule: { height: StyleSheet.hairlineWidth },
  heroFooter: { flexDirection: 'row', gap: 28 },
  heroMetric: { flexDirection: 'row', alignItems: 'center', gap: 9, flex: 1 },
  heroMetricIcon: { width: 27, height: 27, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  heroMetricLabel: { fontFamily: 'Inter_400Regular', fontSize: 11, marginBottom: 3 },
  heroMetricValue: { fontFamily: 'Inter_600SemiBold', fontSize: 13 },
  heroDecoration: {
    width: 150,
    height: 150,
    borderRadius: 80,
    borderWidth: 1,
    position: 'absolute',
    right: -60,
    top: 68,
  },
  section: { gap: 11 },
  panel: { borderWidth: 1, borderRadius: 22, paddingHorizontal: 16 },
  inlineAction: { borderRadius: 13, paddingHorizontal: 16, paddingVertical: 11, marginTop: 5 },
  inlineActionText: { fontFamily: 'Inter_600SemiBold', fontSize: 13 },
  privacyNote: { fontFamily: 'Inter_400Regular', fontSize: 11, lineHeight: 17, textAlign: 'center', paddingHorizontal: 12, marginTop: -4 },
});
