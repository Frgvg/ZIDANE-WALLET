import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import React, { useMemo, useState } from 'react';
import { Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { IconButton, ScreenState, TransactionRow } from '@/components/FinanceUI';
import { useColors } from '@/hooks/useColors';
import { formatMoney, isInCurrentMonth, monthLabel } from '@/lib/finance';
import { useBudget } from '@/providers/BudgetProvider';
import type { TransactionType } from '@/lib/finance';

type Filter = 'all' | TransactionType;

export default function TransactionsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { transactions, currency, isHydrated, storageError, reload } = useBudget();
  const [filter, setFilter] = useState<Filter>('all');

  const monthTransactions = useMemo(
    () => transactions.filter((item) => isInCurrentMonth(item.date)),
    [transactions],
  );
  const filtered = [...monthTransactions]
    .filter((item) => filter === 'all' || item.type === filter)
    .sort((a, b) => b.date.localeCompare(a.date));
  const total = filtered.reduce(
    (sum, item) => sum + (item.type === 'income' ? item.amount : -item.amount),
    0,
  );

  if (!isHydrated) return <ScreenState type="loading" />;
  if (storageError) {
    return <ScreenState type="error" message={storageError} onRetry={() => void reload()} />;
  }

  const topInset = Platform.OS === 'web' ? 67 : insets.top;
  const bottomInset = Platform.OS === 'web' ? 34 : insets.bottom;
  const filters: { id: Filter; label: string }[] = [
    { id: 'all', label: 'All' },
    { id: 'expense', label: 'Expenses' },
    { id: 'income', label: 'Income' },
  ];

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: colors.background }}
      contentContainerStyle={[
        styles.content,
        { paddingTop: topInset + 14, paddingBottom: bottomInset + 112 },
      ]}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.header}>
        <View>
          <Text style={[styles.eyebrow, { color: colors.primary }]}>YOUR MONEY, IN MOTION</Text>
          <Text style={[styles.title, { color: colors.foreground }]}>Activity</Text>
          <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>{monthLabel()}</Text>
        </View>
        <IconButton
          icon="plus"
          label="Add a transaction"
          onPress={() => router.push('/add-transaction')}
        />
      </View>

      <View style={[styles.totalCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <View style={[styles.totalIcon, { backgroundColor: colors.secondary }]}>
          <Feather name="bar-chart-2" size={18} color={colors.primary} />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={[styles.totalLabel, { color: colors.mutedForeground }]}>Net logged this month</Text>
          <Text style={[styles.totalAmount, { color: colors.foreground }]}>
            {total < 0 ? '−' : '+'}{formatMoney(Math.abs(total), currency)}
          </Text>
        </View>
        <Text style={[styles.count, { color: colors.mutedForeground }]}>
          {monthTransactions.length} {monthTransactions.length === 1 ? 'entry' : 'entries'}
        </Text>
      </View>

      <View style={styles.filters}>
        {filters.map((item) => {
          const active = filter === item.id;
          return (
            <Pressable
              key={item.id}
              accessibilityRole="button"
              accessibilityState={{ selected: active }}
              onPress={() => setFilter(item.id)}
              style={({ pressed }) => [
                styles.filterPill,
                {
                  backgroundColor: active ? colors.primary : colors.card,
                  borderColor: active ? colors.primary : colors.border,
                  opacity: pressed ? 0.75 : 1,
                },
              ]}
            >
              <Text style={[styles.filterText, { color: active ? colors.primaryForeground : colors.foreground }]}>
                {item.label}
              </Text>
            </Pressable>
          );
        })}
      </View>

      {filtered.length ? (
        <View style={[styles.list, { backgroundColor: colors.card, borderColor: colors.border }]}>
          {filtered.map((transaction) => (
            <TransactionRow
              key={transaction.id}
              transaction={transaction}
              currency={currency}
              onPress={() =>
                router.push({
                  pathname: '/add-transaction',
                  params: { id: transaction.id },
                })
              }
            />
          ))}
        </View>
      ) : (
        <View style={[styles.empty, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={[styles.emptyIcon, { backgroundColor: colors.secondary }]}>
            <Feather name="inbox" size={22} color={colors.primary} />
          </View>
          <Text style={[styles.emptyTitle, { color: colors.foreground }]}>
            {filter === 'all' ? 'Nothing logged this month' : `No ${filter === 'income' ? 'income' : 'expenses'} yet`}
          </Text>
          <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
            {filter === 'all'
              ? 'Add a transaction to start keeping track.'
              : 'Try another filter or add a new transaction.'}
          </Text>
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: 20, gap: 18 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  eyebrow: { fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 1.4, marginBottom: 7 },
  title: { fontFamily: 'Inter_700Bold', fontSize: 29, letterSpacing: -0.7 },
  subtitle: { fontFamily: 'Inter_400Regular', fontSize: 13, marginTop: 3 },
  totalCard: { borderWidth: 1, borderRadius: 21, padding: 17, flexDirection: 'row', alignItems: 'center', gap: 12 },
  totalIcon: { width: 42, height: 42, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  totalLabel: { fontFamily: 'Inter_400Regular', fontSize: 11, marginBottom: 4 },
  totalAmount: { fontFamily: 'Inter_700Bold', fontSize: 19 },
  count: { fontFamily: 'Inter_500Medium', fontSize: 11 },
  filters: { flexDirection: 'row', gap: 8 },
  filterPill: { paddingVertical: 9, paddingHorizontal: 15, borderRadius: 99, borderWidth: 1 },
  filterText: { fontFamily: 'Inter_500Medium', fontSize: 12 },
  list: { borderWidth: 1, borderRadius: 22, paddingHorizontal: 15 },
  empty: { borderWidth: 1, borderRadius: 22, padding: 24, alignItems: 'center', gap: 9 },
  emptyIcon: { width: 50, height: 50, borderRadius: 18, alignItems: 'center', justifyContent: 'center', marginBottom: 2 },
  emptyTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 16, textAlign: 'center' },
  emptyText: { fontFamily: 'Inter_400Regular', fontSize: 13, lineHeight: 20, textAlign: 'center' },
});
