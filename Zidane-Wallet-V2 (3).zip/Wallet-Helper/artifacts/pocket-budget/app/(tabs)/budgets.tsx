import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import React, { useMemo } from 'react';
import { Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { BudgetProgress, IconButton, ScreenState } from '@/components/FinanceUI';
import { useColors } from '@/hooks/useColors';
import { formatMoney, isInCurrentMonth, monthLabel } from '@/lib/finance';
import { useBudget } from '@/providers/BudgetProvider';

export default function BudgetsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { budgets, transactions, currency, isHydrated, storageError, reload } = useBudget();
  const categorySpending = useMemo(() => {
    const totals = new Map<string, number>();
    for (const transaction of transactions) {
      if (transaction.type === 'expense' && isInCurrentMonth(transaction.date)) {
        totals.set(
          transaction.category,
          (totals.get(transaction.category) ?? 0) + transaction.amount,
        );
      }
    }
    return totals;
  }, [transactions]);

  if (!isHydrated) return <ScreenState type="loading" />;
  if (storageError) {
    return <ScreenState type="error" message={storageError} onRetry={() => void reload()} />;
  }

  const totalLimit = budgets.reduce((sum, budget) => sum + budget.limit, 0);
  const totalUsed = budgets.reduce(
    (sum, budget) => sum + (categorySpending.get(budget.category) ?? 0),
    0,
  );
  const topInset = Platform.OS === 'web' ? 67 : insets.top;
  const bottomInset = Platform.OS === 'web' ? 34 : insets.bottom;

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: colors.background }}
      contentContainerStyle={[
        styles.content,
        { paddingTop: topInset + 14, paddingBottom: bottomInset + 112 },
      ]}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.header}>
        <View>
          <Text style={[styles.eyebrow, { color: colors.primary }]}>A LITTLE ROOM TO BREATHE</Text>
          <Text style={[styles.title, { color: colors.foreground }]}>Budgets</Text>
          <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>{monthLabel()}</Text>
        </View>
        <IconButton
          icon="plus"
          label="Create a monthly budget"
          onPress={() => router.push('/add-budget')}
        />
      </View>

      {budgets.length ? (
        <>
          <View style={[styles.summary, { backgroundColor: colors.primary }]}>
            <Text style={[styles.summaryLabel, { color: colors.primaryForeground, opacity: 0.78 }]}>
              Your monthly limits
            </Text>
            <Text style={[styles.summaryAmount, { color: colors.primaryForeground }]}>
              {formatMoney(totalLimit, currency)}
            </Text>
            <View style={[styles.summaryRule, { backgroundColor: colors.primaryForeground, opacity: 0.22 }]} />
            <View style={styles.summaryBottom}>
              <Text style={[styles.summaryUsed, { color: colors.primaryForeground }]}>
                Used {formatMoney(totalUsed, currency)}
              </Text>
              <Text style={[styles.summaryLeft, { color: colors.accentForeground }]}>
                {formatMoney(Math.max(totalLimit - totalUsed, 0), currency)} left
              </Text>
            </View>
          </View>

          <View style={styles.listHeader}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Category limits</Text>
            <Text style={[styles.hint, { color: colors.mutedForeground }]}>Tap to edit</Text>
          </View>
          <View style={[styles.list, { backgroundColor: colors.card, borderColor: colors.border }]}>
            {budgets.map((budget) => (
              <Pressable
                accessibilityRole="button"
                key={budget.id}
                onPress={() =>
                  router.push({
                    pathname: '/add-budget',
                    params: { id: budget.id },
                  })
                }
                style={({ pressed }) => [
                  styles.budgetItem,
                  { borderBottomColor: colors.border, opacity: pressed ? 0.72 : 1 },
                ]}
              >
                <BudgetProgress
                  budget={budget}
                  spent={categorySpending.get(budget.category) ?? 0}
                  currency={currency}
                />
                <Feather name="chevron-right" size={16} color={colors.mutedForeground} />
              </Pressable>
            ))}
          </View>
        </>
      ) : (
        <View style={[styles.empty, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={[styles.emptyIcon, { backgroundColor: colors.accent }]}>
            <Feather name="target" size={22} color={colors.accentForeground} />
          </View>
          <Text style={[styles.emptyTitle, { color: colors.foreground }]}>Start with one category</Text>
          <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
            Choose a monthly spending limit for something important to you. You can change it anytime.
          </Text>
          <Pressable
            accessibilityRole="button"
            onPress={() => router.push('/add-budget')}
            style={({ pressed }) => [
              styles.createButton,
              { backgroundColor: colors.primary, opacity: pressed ? 0.82 : 1 },
            ]}
          >
            <Feather name="plus" size={17} color={colors.primaryForeground} />
            <Text style={[styles.createButtonText, { color: colors.primaryForeground }]}>Create a budget</Text>
          </Pressable>
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: 20, gap: 19 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  eyebrow: { fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 1.3, marginBottom: 7 },
  title: { fontFamily: 'Inter_700Bold', fontSize: 29, letterSpacing: -0.7 },
  subtitle: { fontFamily: 'Inter_400Regular', fontSize: 13, marginTop: 3 },
  summary: { padding: 21, borderRadius: 24, gap: 8 },
  summaryLabel: { fontFamily: 'Inter_500Medium', fontSize: 12 },
  summaryAmount: { fontFamily: 'Inter_700Bold', fontSize: 28, letterSpacing: -0.5 },
  summaryRule: { height: StyleSheet.hairlineWidth, marginVertical: 6 },
  summaryBottom: { flexDirection: 'row', justifyContent: 'space-between' },
  summaryUsed: { fontFamily: 'Inter_500Medium', fontSize: 12 },
  summaryLeft: { fontFamily: 'Inter_600SemiBold', fontSize: 12 },
  listHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: -8 },
  sectionTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 18 },
  hint: { fontFamily: 'Inter_400Regular', fontSize: 11 },
  list: { borderWidth: 1, borderRadius: 22, paddingHorizontal: 15 },
  budgetItem: { flexDirection: 'row', alignItems: 'center', borderBottomWidth: StyleSheet.hairlineWidth },
  empty: { borderWidth: 1, borderRadius: 24, padding: 24, alignItems: 'center', gap: 10, marginTop: 4 },
  emptyIcon: { width: 54, height: 54, borderRadius: 19, alignItems: 'center', justifyContent: 'center', marginBottom: 3 },
  emptyTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 18, textAlign: 'center' },
  emptyText: { fontFamily: 'Inter_400Regular', fontSize: 13, lineHeight: 20, textAlign: 'center' },
  createButton: { flexDirection: 'row', gap: 8, alignItems: 'center', justifyContent: 'center', borderRadius: 15, paddingHorizontal: 17, paddingVertical: 13, marginTop: 5 },
  createButtonText: { fontFamily: 'Inter_600SemiBold', fontSize: 14 },
});
