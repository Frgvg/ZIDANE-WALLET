import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { router, useLocalSearchParams } from 'expo-router';
import React, { useState } from 'react';
import {
  Alert,
  Keyboard,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { CategoryChip, ScreenState } from '@/components/FinanceUI';
import { useColors } from '@/hooks/useColors';
import { EXPENSE_CATEGORIES, type CategoryId } from '@/lib/finance';
import { useBudget } from '@/providers/BudgetProvider';

export default function AddBudgetScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id?: string }>();
  const { budgets, isHydrated, storageError, reload, saveBudget, removeBudget } = useBudget();
  const budget = id ? budgets.find((item) => item.id === id) : undefined;

  const [category, setCategory] = useState<CategoryId>(
    () => budget?.category ?? EXPENSE_CATEGORIES[0].id,
  );
  const [limit, setLimit] = useState(() => (budget ? String(budget.limit) : ''));
  const [saving, setSaving] = useState(false);

  if (!isHydrated) return <ScreenState type="loading" />;
  if (storageError) {
    return <ScreenState type="error" message={storageError} onRetry={() => void reload()} />;
  }
  if (id && !budget) {
    return <ScreenState type="error" message="This budget could not be found." onRetry={() => router.back()} />;
  }

  const topInset = Platform.OS === 'web' ? 67 : insets.top;
  const bottomInset = Platform.OS === 'web' ? 34 : insets.bottom;
  const parsedLimit = Number(limit.replace(',', '.'));
  const canSave = Number.isFinite(parsedLimit) && parsedLimit > 0 && !saving;
  const availableCategories = EXPENSE_CATEGORIES.filter(
    (item) => item.id === budget?.category || !budgets.some((existing) => existing.category === item.id),
  );

  const submit = async () => {
    if (!canSave) return;
    setSaving(true);
    try {
      await saveBudget({ id: budget?.id, category, limit: parsedLimit });
      void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      router.back();
    } catch (error) {
      Alert.alert('Could not save', error instanceof Error ? error.message : 'Please try again.');
    } finally {
      setSaving(false);
    }
  };

  const confirmDelete = () => {
    if (!budget) return;
    Alert.alert(
      'Remove this budget?',
      'Your transaction history will stay, but this monthly limit will be removed.',
      [
        { text: 'Keep it', style: 'cancel' },
        {
          text: 'Remove',
          style: 'destructive',
          onPress: () => {
            void removeBudget(budget.id)
              .then(() => router.back())
              .catch((error: unknown) => {
                Alert.alert('Could not remove', error instanceof Error ? error.message : 'Please try again.');
              });
          },
        },
      ],
    );
  };

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <KeyboardAwareScrollViewCompat
        style={{ flex: 1 }}
        contentContainerStyle={[
          styles.content,
          { paddingTop: topInset + 10, paddingBottom: bottomInset + 24 },
        ]}
        bottomOffset={24}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.topBar}>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Close"
            onPress={() => router.back()}
            hitSlop={10}
            style={[styles.closeButton, { backgroundColor: colors.secondary }]}
          >
            <Feather name="x" size={19} color={colors.foreground} />
          </Pressable>
          <Text style={[styles.screenTitle, { color: colors.foreground }]}>
            {budget ? 'Edit budget' : 'New budget'}
          </Text>
          <View style={{ width: 42 }} />
        </View>

        <View style={[styles.intro, { backgroundColor: colors.primary }]}>
          <View style={[styles.introIcon, { backgroundColor: colors.accent }]}>
            <Feather name="target" size={20} color={colors.accentForeground} />
          </View>
          <Text style={[styles.introTitle, { color: colors.primaryForeground }]}>
            Make room for what matters.
          </Text>
          <Text style={[styles.introText, { color: colors.primaryForeground, opacity: 0.78 }]}>
            Pick a category and decide what feels comfortable for a month.
          </Text>
        </View>

        <View style={styles.fieldGroup}>
          <Text style={[styles.fieldLabel, { color: colors.foreground }]}>Category</Text>
          <View style={styles.categoryGrid}>
            {availableCategories.map((item) => (
              <CategoryChip
                key={item.id}
                category={item}
                selected={category === item.id}
                onPress={() => setCategory(item.id)}
              />
            ))}
          </View>
        </View>

        <View style={styles.fieldGroup}>
          <Text style={[styles.fieldLabel, { color: colors.foreground }]}>Monthly limit</Text>
          <View style={[styles.amountCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <TextInput
              accessibilityLabel="Monthly spending limit in XOF"
              testID="budget-limit"
              value={limit}
              onChangeText={(value) =>
                setLimit(value.replace(/[^0-9.,]/g, '').replace(/([.,].*)[.,]/g, '$1'))
              }
              keyboardType="decimal-pad"
              placeholder="0"
              placeholderTextColor={colors.mutedForeground}
              style={[styles.amountInput, { color: colors.foreground }]}
              autoFocus={!budget}
              returnKeyType="done"
              onSubmitEditing={Keyboard.dismiss}
            />
            <Text style={[styles.amountCurrency, { color: colors.mutedForeground }]}>FCFA / month</Text>
          </View>
          <Text style={[styles.helper, { color: colors.mutedForeground }]}>
            You can adjust this limit whenever your plans change.
          </Text>
        </View>

        <Pressable
          accessibilityRole="button"
          accessibilityState={{ disabled: !canSave }}
          testID="save-budget"
          disabled={!canSave}
          onPress={() => void submit()}
          style={({ pressed }) => [
            styles.saveButton,
            { backgroundColor: colors.primary, opacity: !canSave ? 0.45 : pressed ? 0.82 : 1 },
          ]}
        >
          <Text style={[styles.saveButtonText, { color: colors.primaryForeground }]}>
            {saving ? 'Saving…' : budget ? 'Save changes' : 'Create budget'}
          </Text>
          <Feather name="arrow-right" size={18} color={colors.primaryForeground} />
        </Pressable>

        {budget ? (
          <Pressable accessibilityRole="button" onPress={confirmDelete} style={styles.deleteButton}>
            <Feather name="trash-2" size={16} color={colors.destructive} />
            <Text style={[styles.deleteText, { color: colors.destructive }]}>Remove budget</Text>
          </Pressable>
        ) : null}
      </KeyboardAwareScrollViewCompat>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  content: { paddingHorizontal: 22, gap: 22 },
  topBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  closeButton: { width: 42, height: 42, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  screenTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 17 },
  intro: { borderRadius: 22, padding: 19, gap: 8 },
  introIcon: { width: 40, height: 40, borderRadius: 14, alignItems: 'center', justifyContent: 'center', marginBottom: 3 },
  introTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 18 },
  introText: { fontFamily: 'Inter_400Regular', fontSize: 13, lineHeight: 19 },
  fieldGroup: { gap: 10 },
  fieldLabel: { fontFamily: 'Inter_600SemiBold', fontSize: 14 },
  categoryGrid: { flexDirection: 'row', flexWrap: 'wrap', marginRight: -8 },
  amountCard: { minHeight: 62, borderWidth: 1, borderRadius: 17, paddingHorizontal: 16, flexDirection: 'row', alignItems: 'center' },
  amountInput: { flex: 1, minWidth: 0, fontFamily: 'Inter_700Bold', fontSize: 23 },
  amountCurrency: { fontFamily: 'Inter_500Medium', fontSize: 11, marginLeft: 8 },
  helper: { fontFamily: 'Inter_400Regular', fontSize: 11, lineHeight: 17 },
  saveButton: { minHeight: 54, borderRadius: 17, paddingHorizontal: 18, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 1 },
  saveButtonText: { fontFamily: 'Inter_600SemiBold', fontSize: 15 },
  deleteButton: { minHeight: 42, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, marginTop: -8 },
  deleteText: { fontFamily: 'Inter_600SemiBold', fontSize: 13 },
});
