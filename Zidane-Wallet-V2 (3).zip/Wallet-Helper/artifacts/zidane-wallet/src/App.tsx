import { type ReactNode, createContext, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, useLocation, Router as WouterRouter, Link } from 'wouter';
import { ArrowDownLeft, ArrowLeft, ArrowRight, ArrowUpRight, BadgeCheck, Bitcoin, Check, ChevronRight, CircleHelp, Copy, Eye, EyeOff, Fingerprint, History, LockKeyhole, Search, Shield, ShieldCheck, Sparkles, Wallet, X } from 'lucide-react';
import { Form } from '@/components/ui/form';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import {
  formatBtcAmount,
  formatSatoshis,
  parseBtcAmountToSatoshis,
  prepareDemoSend,
  prepareDemoSendFromSatoshis,
  satoshisToBtc,
  type DemoSendFailure,
} from './lib/btc-amount';
import {
  getDisplayedTransactions,
  getOrCreatePendingSimulatedTransactionId,
  nextSimulatedTransactionTimestamp,
  loadDemoWallet,
  persistDemoWallet,
  recordSimulatedTransaction,
  removeDemoWallet,
  type DemoSettings,
  type DemoStorage,
  type DemoTransaction,
  type WalletData,
} from './lib/demo-wallet-persistence';
import { filterDemoTransactions, type TransactionDirectionFilter } from './lib/transaction-history';

type SendReview = { recipient: string; amountSatoshis: bigint; transactionId: string };
const sampleTransactions: DemoTransaction[] = [
  { id:'tx-01', label:'Demo deposit', direction:'in', amountBtc:.025, sampleFiatValue:1678.25, date:'Today · 10:42 AM', status:'Sample', addressLabel:'Sample activity' },
  { id:'tx-02', label:'Coffee & company', direction:'out', amountBtc:.0018, sampleFiatValue:120.83, date:'Yesterday · 2:18 PM', status:'Sample', addressLabel:'Demo recipient label' },
  { id:'tx-03', label:'Demo deposit', direction:'in', amountBtc:.06111, sampleFiatValue:4102.31, date:'May 18 · 9:06 AM', status:'Sample', addressLabel:'Sample activity' },
];
const startingBalance = .08431;
const price = 67130;
const defaults: WalletData = { created:false, balanceBtc:startingBalance, sampleFiatValue:startingBalance * price, simulatedTransactions:[], settings:{ hideBalance:false, autoLock:true, confirmationStep:true } };
const Store = createContext<{ wallet:WalletData; setWallet:(v:WalletData | ((old:WalletData)=>WalletData))=>void; save:(nextWallet?:WalletData)=>void; reset:()=>void; persistenceWarning:boolean } | null>(null);
const queryClient = new QueryClient();

function useWallet() {
  const value = useContext(Store);
  if (!value) throw new Error('Wallet store unavailable');
  return value;
}
function Brand() {
  return <Link href="/" className="brand" data-testid="link-home"><span className="brand-mark">Z</span><span>ZIDANE <span style={{color:'#c9a85c'}}>WALLET</span></span></Link>;
}
const navItems = [
  { href:'/dashboard', label:'Wallet', icon:Wallet },
  { href:'/receive', label:'Receive', icon:ArrowDownLeft },
  { href:'/send', label:'Send', icon:ArrowUpRight },
  { href:'/history', label:'Activity', icon:History },
  { href:'/security', label:'Security', icon:Shield },
];
function Shell({ children }: { children:ReactNode }) {
  const [location] = useLocation();
  const { wallet, persistenceWarning } = useWallet();
  return <div className="wallet-shell"><div className="grain" />
    <header className="wallet-nav"><Brand />
      <nav className="nav-links" aria-label="Wallet navigation">{navItems.map(({href,label,icon:Icon})=><Link key={href} href={href} aria-current={location===href?'page':undefined} className={`nav-link ${location===href?'active':''}`} data-testid={`link-nav-${label.toLowerCase()}`}><span><Icon size={17} aria-hidden="true" /></span>{label}</Link>)}</nav>
      <span className="demo-chip" data-testid="status-demo-mode">DEMO MODE</span>
    </header>
    {persistenceWarning&&<div className="content" style={{paddingBottom:0}}><div className="notice" role="alert" data-testid="status-storage-warning">This browser could not save demo data. Refreshing may erase simulated transactions.</div></div>}
    <main>{children}</main>
    <footer className="app-footer">A SAFE PLACE TO EXPLORE · NO REAL BITCOIN MOVES HERE</footer>
  </div>;
}
function Notice({ children }: { children:ReactNode }) {
  return <div className="notice" role="note" data-testid="notice-demo-warning"><ShieldCheck size={17} style={{flex:'none',marginTop:1}}/><div><b>Demo only.</b> {children}</div></div>;
}
function Title({ eyebrow, title, subtitle }: { eyebrow:string; title:string; subtitle?:string }) {
  return <div style={{marginBottom:25}}><div className="eyebrow">{eyebrow}</div><h1 className="page-title">{title}</h1>{subtitle&&<p className="muted" style={{fontSize:13,margin:0,lineHeight:1.7}}>{subtitle}</p>}</div>;
}
function Amount({ value, hide=false }: { value:number; hide?:boolean }) {
  return <>{hide?'••••••':formatBtcAmount(value)} <span style={{color:'#a69e87',fontSize:'.58em'}}>BTC</span></>;
}
function Welcome() {
  const {wallet}=useWallet();
  return <Shell><div className="content">
    <div className="welcome-hero">
      <div><div className="eyebrow" style={{display:'flex',alignItems:'center',gap:9}}><span style={{width:25,height:1,background:'#c4a55d'}}/>BITCOIN, WITHOUT THE STAKES</div>
        <h1 className="serif" style={{fontSize:'clamp(48px,8vw,82px)',lineHeight:.99,letterSpacing:'-.055em',fontWeight:500,margin:'22px 0'}}>A wallet.<br/><span style={{color:'#c9aa63',fontStyle:'italic'}}>Just to explore.</span></h1>
        <p className="muted" style={{maxWidth:435,lineHeight:1.85,fontSize:14,margin:'23px 0 27px'}}>Get comfortable with the essentials of a Bitcoin wallet in a safe, hands-on demo. No accounts, no keys, no real funds—just a thoughtfully made place to learn.</p>
        <div style={{display:'flex',gap:11,flexWrap:'wrap'}}><Link href={wallet.created?'/dashboard':'/create-wallet'} className="primary-btn" data-testid="button-start-demo">{wallet.created?'Open your demo wallet':'Explore the demo wallet'}<ArrowRight size={16}/></Link><Link href="/security" className="secondary-btn" data-testid="link-security-intro"><Shield size={15}/>Safety details</Link></div>
        <div style={{display:'flex',gap:23,marginTop:33,color:'#999386',fontSize:11}}><span style={{display:'flex',gap:7,alignItems:'center'}}><Check size={13} color="#c6a75f"/>No seed phrase</span><span style={{display:'flex',gap:7,alignItems:'center'}}><Check size={13} color="#c6a75f"/>No blockchain</span></div>
      </div>
      <div className="panel" style={{padding:24,position:'relative',overflow:'hidden',minHeight:340}}>
        <div style={{position:'absolute',width:260,height:260,border:'1px solid rgba(201,170,99,.16)',borderRadius:'50%',right:-110,top:-125}}/><div style={{position:'absolute',width:190,height:190,border:'1px solid rgba(201,170,99,.12)',borderRadius:'50%',right:-75,top:-90}}/>
        <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',position:'relative'}}><span className="eyebrow">YOUR PRACTICE SPACE</span><span style={{width:8,height:8,borderRadius:10,background:'#8da57a',boxShadow:'0 0 0 4px rgba(141,165,122,.12)'}}/></div>
        <div style={{marginTop:50,position:'relative'}}><div className="muted" style={{fontSize:12}}>Available demo balance</div><div className="serif" style={{fontSize:40,marginTop:8,letterSpacing:'-.04em'}}>0.08431 <span style={{font:'500 15px var(--app-font-mono)',color:'#b4aa91'}}>BTC</span></div><div className="mono" style={{fontSize:12,color:'#958f82',marginTop:6}}>≈ $5,659.73 USD · SAMPLE VALUE</div></div>
        <div style={{height:1,background:'rgba(221,204,166,.12)',margin:'27px 0 18px'}}/>
        <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}><div><div className="muted" style={{fontSize:11}}>A clear view, every step</div><div style={{fontSize:13,marginTop:5}}>Practice at your own pace</div></div><div className="brand-mark" style={{width:42,height:42,fontSize:21}}><Bitcoin size={20}/></div></div>
      </div>
    </div>
    <div className="welcome-steps">
      {[['01','Look around','See a sample balance and activity.'],['02','Try an action','Send and receive are simulations only.'],['03','Stay in control','Preferences are local to this demo.']].map(x=><div key={x[0]} style={{display:'flex',gap:13}}><span className="mono" style={{color:'#bd9d55',fontSize:11}}>{x[0]}</span><div><div style={{fontWeight:700,fontSize:12,marginBottom:5}}>{x[1]}</div><div className="muted" style={{fontSize:11}}>{x[2]}</div></div></div>)}
    </div>
  </div></Shell>;
}
function CreateWallet() {
  const {wallet,setWallet,save}=useWallet();
  const [,go]=useLocation();
  function create() { const nextWallet={...wallet,created:true}; setWallet(nextWallet); save(nextWallet); go('/dashboard'); }
  return <Shell><div className="content" style={{maxWidth:700}}>
    <Link href="/" className="muted" style={{display:'inline-flex',alignItems:'center',gap:8,fontSize:12,marginBottom:24}} data-testid="link-back-home"><ArrowLeft size={15}/>Back to introduction</Link>
    <Title eyebrow="GET STARTED · 01" title="Set up your demo" subtitle="This creates a practice wallet view in this browser. Nothing is generated, stored, or connected."/>
    <Notice>This is a visual simulation. It will not create a Bitcoin wallet, seed phrase, private key, or address.</Notice>
    <section className="panel" style={{padding:'27px 26px',marginTop:20}}>
      <div style={{display:'flex',gap:15,alignItems:'center',marginBottom:24}}><div className="brand-mark"><Sparkles size={16}/></div><div><div style={{fontWeight:800,fontSize:15}}>Your demo wallet</div><div className="muted" style={{fontSize:12,marginTop:4}}>Ready in one tap. No sign-up needed.</div></div></div>
      <div style={{display:'grid',gap:12,marginBottom:24}}>{[['Sample balance','Example BTC and fiat figures'],['Practice activity','A few fictional transactions'],['Private by design','No secrets or actual wallet data']].map(([a,b])=><div key={a} style={{display:'flex',justifyContent:'space-between',padding:'13px 0',borderTop:'1px solid rgba(221,204,166,.1)'}}><span style={{fontSize:12,fontWeight:700}}>{a}</span><span className="muted" style={{fontSize:11}}>{b}</span></div>)}</div>
      <button onClick={create} className="primary-btn" style={{width:'100%'}} data-testid="button-create-demo">Create demo wallet <ArrowRight size={16}/></button>
      <p className="muted" style={{fontSize:10,textAlign:'center',margin:'13px 0 0'}}>By continuing, you are opening a local-only product demo.</p>
    </section>
  </div></Shell>;
}
function TransactionList({ transactions, compact=false }: { transactions:DemoTransaction[]; compact?:boolean }) {
  if(!transactions.length) return <div className="panel" style={{padding:27,textAlign:'center'}}><div className="muted" style={{fontSize:12}}>No activity yet. Simulated sends will appear here.</div></div>;
  const rows=compact?transactions.slice(0,3):transactions;
  return <div>{rows.map(tx=><div className="transaction-row" key={tx.id} data-testid={`row-transaction-${tx.id}`}><div className="tx-icon">{tx.direction==='in'?<ArrowDownLeft size={17}/>:<ArrowUpRight size={17}/>}</div><div className="tx-grid"><div className="tx-label">{tx.label}</div><div className="tx-amount" data-testid={`text-transaction-amount-${tx.id}`} style={{color:tx.direction==='in'?'#a8bd8f':'#e1d8c4'}}>{tx.direction==='in'?'+':'−'}{formatBtcAmount(tx.amountBtc)} BTC</div><div className="tx-date">{tx.date} · {tx.addressLabel}</div><div className="tx-status">{tx.status}</div></div></div>)}</div>;
}
function Dashboard() {
  const {wallet,setWallet,save}=useWallet();
  const hidden=wallet.settings.hideBalance;
  const displayedTransactions=getDisplayedTransactions(sampleTransactions,wallet.simulatedTransactions);
  const simulatedCount=wallet.simulatedTransactions.length;
  const receivedCount=displayedTransactions.filter(tx=>tx.direction==='in').length;
  const sentCount=displayedTransactions.filter(tx=>tx.direction==='out').length;
  function toggleBalance() {
    const next={...wallet,settings:{...wallet.settings,hideBalance:!hidden}};
    setWallet(next);
    save(next);
  }
  return <Shell><div className="content dashboard-v2">
    <div className="security-banner" role="note" data-testid="banner-dashboard-security">
      <div className="security-banner-icon"><ShieldCheck size={18}/></div>
      <div><strong>Demo environment · Your safety comes first</strong><span>All balances and activity are fictional. No private keys, blockchain connection, or real Bitcoin transfers.</span></div>
      <Link href="/security" aria-label="Read security details"><ChevronRight size={18}/></Link>
    </div>
    <div className="dashboard-heading-v2"><div><div className="eyebrow">YOUR OVERVIEW</div><h1 className="page-title">Good to see you.</h1><p className="muted dashboard-subtitle">A clear picture of your practice portfolio.</p></div><span className="demo-chip">DEMO MODE</span></div>
    <section className="portfolio-card panel" aria-label="Sample portfolio summary">
      <div className="portfolio-card-top"><div><div className="portfolio-label">TOTAL PORTFOLIO VALUE <span className="portfolio-demo-tag">SAMPLE</span></div><div className="portfolio-fiat" data-testid="text-fiat-balance">{hidden?'••••••':`$${wallet.sampleFiatValue.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})}`}<span> USD</span></div></div><button className="balance-visibility" type="button" onClick={toggleBalance} aria-label={hidden?'Show sample balance':'Hide sample balance'} aria-pressed={hidden}>{hidden?<Eye size={16}/>:<EyeOff size={16}/>}<span>{hidden?'Show':'Hide'}</span></button></div>
      <div className="portfolio-divider"/>
      <div className="portfolio-bottom"><div><div className="portfolio-label">BITCOIN BALANCE</div><div className="portfolio-btc mono" data-testid="text-wallet-balance">{hidden?'••••••':formatBtcAmount(wallet.balanceBtc)} <span>BTC</span></div></div><div className="portfolio-coin"><Bitcoin size={23}/></div></div>
      <div className="portfolio-actions"><Link href="/send" className="primary-btn" data-testid="button-wallet-send"><ArrowUpRight size={16}/>Send</Link><Link href="/receive" className="portfolio-secondary" data-testid="button-wallet-receive"><ArrowDownLeft size={16}/>Receive</Link><Link href="/history" className="portfolio-secondary" data-testid="button-wallet-history"><History size={16}/>Activity</Link></div>
    </section>
    <div className="dashboard-metrics" aria-label="Sample activity summary">
      <div className="metric-card"><span className="metric-icon"><Wallet size={16}/></span><span className="metric-label">Transactions</span><strong data-testid="metric-transaction-count">{displayedTransactions.length}</strong><small>In this demo</small></div>
      <div className="metric-card"><span className="metric-icon metric-in"><ArrowDownLeft size={16}/></span><span className="metric-label">Received</span><strong data-testid="metric-received-count">{receivedCount}</strong><small>Sample entries</small></div>
      <div className="metric-card"><span className="metric-icon metric-out"><ArrowUpRight size={16}/></span><span className="metric-label">Sent</span><strong data-testid="metric-sent-count">{sentCount}</strong><small>{simulatedCount} simulated by you</small></div>
    </div>
    <div className="dashboard-grid dashboard-grid-v2">
      <section className="panel dashboard-activity-panel"><div className="dashboard-section-heading"><div><div className="eyebrow">LATEST MOVEMENT</div><h2>Recent activity</h2></div><Link href="/history" className="eyebrow" style={{fontSize:9}} data-testid="link-all-activity">VIEW ALL <ChevronRight size={12} style={{verticalAlign:'-3px'}}/></Link></div><TransactionList transactions={displayedTransactions} compact/></section>
      <section className="panel dashboard-security-card"><div className="security-card-top"><div className="tx-icon"><LockKeyhole size={17}/></div><span className="security-status-dot"/></div><div className="eyebrow">SECURITY CENTER</div><h2>Practice with confidence.</h2><p className="muted">Explore wallet features in a controlled demo. Your sample activity stays in this browser.</p><Link href="/security" className="secondary-btn" style={{width:'100%',minHeight:42,fontSize:11}} data-testid="link-wallet-security">Review safety settings <ArrowRight size={14}/></Link></section>
    </div>
    <p className="dashboard-footnote"><Shield size={13}/> Demo figures are illustrative only and do not represent funds you own.</p>
  </div></Shell>;
}
function Receive() {
  const [copyState,setCopyState]=useState<'idle'|'copied'|'unavailable'>('idle');
  const demoAddress='DEMO-ONLY-NOT-A-BITCOIN-ADDRESS';
  async function copy(){
    try{await navigator.clipboard.writeText(demoAddress);setCopyState('copied');}
    catch{setCopyState('unavailable');}
    window.setTimeout(()=>setCopyState('idle'),2600);
  }
  return <Shell><div className="content" style={{maxWidth:720}}>
    <Title eyebrow="RECEIVE · PRACTICE" title="Explore receiving" subtitle="In a real wallet, this is where you would share a receiving address. Here, we keep it safely fictional."/>
    <Notice>The string below is intentionally not a valid Bitcoin address. It cannot receive funds. No address or QR code has been generated.</Notice>
    <section className="panel" style={{padding:26,marginTop:20}}>
      <div style={{fontWeight:800,fontSize:14,marginBottom:7}}>Demo receive label</div><div className="muted" style={{fontSize:12,marginBottom:20}}>For display and interface practice only</div>
      <div className="mono" style={{border:'1px dashed rgba(205,171,98,.4)',background:'rgba(0,0,0,.19)',borderRadius:12,padding:'18px 14px',color:'#dfc37a',fontSize:'clamp(12px,3vw,15px)',textAlign:'center',overflowWrap:'anywhere'}} data-testid="text-fictional-address">{demoAddress}</div>
      <button onClick={copy} className="secondary-btn" style={{width:'100%',marginTop:14}} data-testid="button-copy-demo-label">{copyState==='copied'?<Check size={15}/>:<Copy size={15}/>} {copyState==='copied'?'Demo label copied':'Copy demo label'}</button>
      {copyState==='copied'&&<div className="inline-status" role="status" aria-live="polite" data-testid="status-copy-demo-label">Demo label copied. It is not a Bitcoin address and cannot receive funds.</div>}
      {copyState==='unavailable'&&<div className="inline-status warning" role="status" aria-live="polite" data-testid="status-copy-demo-label">Clipboard access is unavailable. You can select and copy the fictional label above.</div>}
    </section>
    <div className="panel" style={{padding:20,marginTop:14,display:'flex',gap:13}}><CircleHelp size={18} color="#c6a75f" style={{flex:'none'}}/><div><div style={{fontSize:12,fontWeight:800}}>Why no QR code?</div><p className="muted" style={{fontSize:11,lineHeight:1.7,margin:'5px 0 0'}}>QR codes can be mistaken for payment destinations. This demo uses no real address, so it never creates one.</p></div></div>
  </div></Shell>;
}
const amountValidationMessage='Enter a positive BTC amount with up to 8 decimal places.';
const sendSchema=z.object({
  recipient:z.string().trim().min(4,'Enter a demo recipient label.'),
  amount:z.string().trim().refine(value=>{
    const satoshis=parseBtcAmountToSatoshis(value);
    return satoshis!==null&&satoshis>0n;
  },amountValidationMessage),
});
function sendFailureMessage(reason:DemoSendFailure) {
  if(reason==='exceeds-balance') return 'That amount is above the sample balance. Try a smaller amount.';
  if(reason==='invalid-balance') return 'The sample balance is invalid. Reset the demo before sending.';
  return amountValidationMessage;
}
function Send() {
  const {wallet,setWallet,save}=useWallet();
  const [complete,setComplete]=useState(false);
  const [review,setReview]=useState<SendReview | null>(null);
  const [error,setError]=useState('');
  const pendingTransactionId=useRef<string|null>(null);
  const form=useForm<z.infer<typeof sendSchema>>({resolver:zodResolver(sendSchema),defaultValues:{recipient:'',amount:''}});
  const inputAmountSatoshis=parseBtcAmountToSatoshis(form.watch('amount'));
  function finalize(recipient:string,amountSatoshis:bigint,transactionId:string) {
    const prepared=prepareDemoSendFromSatoshis(amountSatoshis,wallet.balanceBtc);
    if(!prepared.ok){setError(sendFailureMessage(prepared.reason));return;}
    setError('');
    const transaction:DemoTransaction={id:transactionId,label:'Simulated send',direction:'out',amountBtc:prepared.amountBtc,sampleFiatValue:prepared.amountBtc*price,date:'Just now',status:'Local simulation · not sent',addressLabel:recipient,createdAt:nextSimulatedTransactionTimestamp(wallet.simulatedTransactions)};
    const result=recordSimulatedTransaction(wallet,transaction,startingBalance,price);
    if(!result.recorded&&result.reason!=='duplicate'){setError('This demo send could not be saved. Please try again.');return;}
    save(result.wallet);
    setWallet(result.wallet);
    setReview(null);
    setComplete(true);
  }
  function simulate(data:z.infer<typeof sendSchema>) {
    const prepared=prepareDemoSend(data.amount,wallet.balanceBtc);
    if(!prepared.ok){setError(sendFailureMessage(prepared.reason));return;}
    setError('');
    const transactionId=getOrCreatePendingSimulatedTransactionId(
      pendingTransactionId.current,
      getDisplayedTransactions(sampleTransactions,wallet.simulatedTransactions),
      ()=>crypto.randomUUID(),
    );
    pendingTransactionId.current=transactionId;
    if(wallet.settings.confirmationStep){setReview({recipient:data.recipient,amountSatoshis:prepared.amountSatoshis,transactionId});return;}
    finalize(data.recipient,prepared.amountSatoshis,transactionId);
  }
  return <Shell><div className="content" style={{maxWidth:760}}>
    <Title eyebrow="SEND · SIMULATION" title="Practice a send" subtitle="Walk through the form without signing, broadcasting, or contacting a blockchain."/>
    <Notice>Nothing will be transferred. This only changes the sample balance and activity stored locally in this demo.</Notice>
    <div className="send-grid">
      <section className="panel" style={{padding:24}}>
        {complete?<div style={{textAlign:'center',padding:'18px 4px'}}><div className="brand-mark" style={{width:49,height:49,margin:'0 auto 17px'}}><Check size={21}/></div><div className="eyebrow">LOCAL DEMO ACTION</div><h2 className="serif" style={{fontSize:27,fontWeight:500}}>Simulation complete</h2><p className="muted" style={{fontSize:12,lineHeight:1.7}}>A sample send was added to your activity. No network request or real transfer occurred.</p><div style={{display:'flex',gap:9,justifyContent:'center',flexWrap:'wrap',marginTop:20}}><button className="secondary-btn" onClick={()=>{pendingTransactionId.current=null;setComplete(false);form.reset();}} data-testid="button-another-simulation">Try another</button><Link href="/history" className="primary-btn" data-testid="link-simulation-history">View activity <ArrowRight size={15}/></Link></div></div>
        :review?<div style={{padding:'10px 2px'}}>
          <div className="eyebrow">REVIEW · DEMO ONLY</div>
          <h2 className="serif" style={{fontSize:27,fontWeight:500,margin:'9px 0 18px'}}>Confirm sample details</h2>
          <div style={{display:'flex',justifyContent:'space-between',padding:'13px 0',borderTop:'1px solid rgba(221,204,166,.1)',fontSize:12}}><span className="muted">Recipient label</span><span>{review.recipient}</span></div>
          <div style={{display:'flex',justifyContent:'space-between',padding:'13px 0',borderTop:'1px solid rgba(221,204,166,.1)',fontSize:12}} data-testid="text-review-send-amount"><span className="muted">Sample amount</span><span className="mono">{formatSatoshis(review.amountSatoshis)} BTC</span></div>
          <Notice>Confirming updates only the sample balance and local activity. It does not send Bitcoin.</Notice>
          {error&&<div role="alert" style={{color:'#e29b88',fontSize:11,marginTop:13}} data-testid="status-send-error">{error}</div>}
          <div style={{display:'flex',gap:9,marginTop:18,flexWrap:'wrap'}}>
            <button className="secondary-btn" onClick={()=>{setError('');setReview(null);}} data-testid="button-edit-demo-send">Edit details</button>
            <button className="primary-btn" onClick={()=>finalize(review.recipient,review.amountSatoshis,review.transactionId)} data-testid="button-confirm-demo-send">Confirm demo send <ArrowRight size={15}/></button>
          </div>
        </div>
        :<Form {...form}><form onSubmit={form.handleSubmit(simulate)} noValidate><div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:23}}><div style={{fontSize:15,fontWeight:800}}>Send bitcoin</div><span className="eyebrow" style={{fontSize:9}}>SIMULATION ONLY</span></div>
          <label className="field-label" htmlFor="recipient">Recipient label</label><input id="recipient" className="field" placeholder="e.g. Sample merchant" {...form.register('recipient')} data-testid="input-recipient"/>
          {form.formState.errors.recipient&&<div style={{color:'#e29b88',fontSize:11,marginTop:6}}>{form.formState.errors.recipient.message}</div>}
          <div style={{height:18}}/><label className="field-label" htmlFor="amount">Amount</label><div style={{position:'relative'}}><input id="amount" className="field mono" type="number" min="0" step="0.00000001" placeholder="0.00000000" {...form.register('amount')} data-testid="input-send-amount"/><span className="mono muted" style={{position:'absolute',right:13,top:16,fontSize:11,pointerEvents:'none'}}>BTC</span></div>
          {form.formState.errors.amount&&<div style={{color:'#e29b88',fontSize:11,marginTop:6}} data-testid="status-send-amount-validation">{form.formState.errors.amount.message}</div>}
          <div style={{display:'flex',justifyContent:'space-between',fontSize:10,color:'#969082',marginTop:9}}><span>Available (sample)</span><span className="mono">{formatBtcAmount(wallet.balanceBtc)} BTC</span></div>
          {inputAmountSatoshis!==null&&inputAmountSatoshis>0n&&<div className="mono muted" style={{fontSize:10,marginTop:7}}>Sample estimate: ≈ ${(satoshisToBtc(inputAmountSatoshis)*price).toFixed(2)} USD</div>}
          {error&&<div role="alert" style={{color:'#e29b88',fontSize:11,marginTop:13}} data-testid="status-send-error">{error}</div>}
          <button type="submit" className="primary-btn" style={{width:'100%',marginTop:23}} data-testid="button-simulate-send">Simulate demo send <ArrowRight size={15}/></button>
          <p className="muted" style={{fontSize:10,lineHeight:1.6,textAlign:'center',margin:'12px 0 0'}}>Submitting updates only this browser's demo state.</p>
        </form></Form>}
      </section>
      <aside className="panel" style={{padding:21}}><div className="tx-icon" style={{marginBottom:15}}><Fingerprint size={18}/></div><div style={{fontSize:13,fontWeight:800}}>No keys. No network.</div><p className="muted" style={{fontSize:11,lineHeight:1.75}}>There is no transaction signing, blockchain connection, or external service behind this form. A send is simply a local activity entry.</p><div style={{borderTop:'1px solid rgba(221,204,166,.12)',paddingTop:13,fontSize:10,color:'#c0bba9'}}>Current sample balance <span className="mono" style={{display:'block',marginTop:6,color:'#e4d4a5'}}>{formatBtcAmount(wallet.balanceBtc)} BTC</span></div></aside>
    </div>
  </div></Shell>;
}
function HistoryPage() {
  const {wallet}=useWallet();
  const displayedTransactions=getDisplayedTransactions(sampleTransactions,wallet.simulatedTransactions);
  const [query,setQuery]=useState('');
  const [direction,setDirection]=useState<TransactionDirectionFilter>('all');
  const filteredTransactions=filterDemoTransactions(displayedTransactions,query,direction);
  const filters:[TransactionDirectionFilter,string][]=[['all','All'],['in','Received'],['out','Sent']];
  return <Shell><div className="content" style={{maxWidth:800}}>
    <Title eyebrow="ACTIVITY · LOCAL DEMO" title="Wallet history" subtitle="Sample transactions plus any sends you simulate in this browser."/>
    <Notice>Every item here is fictional sample activity. Simulated sends are never broadcast to the Bitcoin network.</Notice>
    <section className="panel history-panel" style={{padding:'11px 22px',marginTop:20}}>
      <div className="history-heading">
        <div><h2>Transactions</h2><p className="muted" aria-live="polite" data-testid="text-history-results">{filteredTransactions.length} of {displayedTransactions.length} shown</p></div>
        <span className="eyebrow" style={{fontSize:9}} data-testid="text-transaction-count">{displayedTransactions.length} ITEMS</span>
      </div>
      <div className="history-controls">
        <label className="history-search-wrap">
          <Search size={16} aria-hidden="true"/>
          <input className="field history-search" type="search" value={query} onChange={(event)=>setQuery(event.target.value)} placeholder="Search activity" aria-label="Search transactions" data-testid="input-history-search"/>
          {query&&<button type="button" className="clear-search" onClick={()=>setQuery('')} aria-label="Clear transaction search" data-testid="button-clear-history-search"><X size={15}/></button>}
        </label>
        <div className="history-filters" role="group" aria-label="Filter transactions by direction">
          {filters.map(([value,label])=><button key={value} type="button" className={`filter-chip ${direction===value?'active':''}`} aria-pressed={direction===value} onClick={()=>setDirection(value)} data-testid={`filter-history-${value}`}>{label}</button>)}
        </div>
      </div>
      {filteredTransactions.length
        ? <TransactionList transactions={filteredTransactions}/>
        : <div className="history-empty" data-testid="empty-history-filter"><div className="tx-icon"><Search size={16}/></div><div><strong>No matching activity</strong><p className="muted">Try a different search or filter to see more transactions.</p></div><button type="button" className="secondary-btn" onClick={()=>{setQuery('');setDirection('all');}}>Clear filters</button></div>}
    </section>
  </div></Shell>;
}
function Toggle({ value, onChange, label }: { value:boolean; onChange:()=>void; label:string }) {
  return <button role="switch" aria-checked={value} aria-label={label} onClick={onChange} className={`toggle ${value?'on':''}`} data-testid={`toggle-${label.toLowerCase().replaceAll(' ','-')}`}><span className="toggle-dot"/></button>;
}
function Security() {
  const {wallet,setWallet,save,reset}=useWallet();
  function change(key:keyof DemoSettings) { setWallet({...wallet,settings:{...wallet.settings,[key]:!wallet.settings[key]}}); }
  return <Shell><div className="content" style={{maxWidth:780}}>
    <Title eyebrow="PREFERENCES · LOCAL ONLY" title="Demo preferences" subtitle="Try the controls and see how a wallet interface might behave. These are not security protections."/>
    <Notice>No private keys are stored. These settings affect only the demo interface and do not secure actual cryptocurrency or a real wallet.</Notice>
    <section className="panel" style={{padding:'7px 23px',marginTop:20}}>
      {[{key:'hideBalance' as const,title:'Hide sample balance',description:'Mask the demo BTC and fiat values on your wallet screen.',icon:EyeOff},{key:'autoLock' as const,title:'Auto-lock preview',description:'A preference preview only; this demo does not lock or authenticate.',icon:LockKeyhole},{key:'confirmationStep' as const,title:'Show send confirmation',description:'Keep a review step visible before local simulation.',icon:BadgeCheck}].map(({key,title,description,icon:Icon})=><div key={key} style={{display:'flex',alignItems:'center',gap:15,padding:'18px 0',borderBottom:'1px solid rgba(221,204,166,.1)'}}><div className="tx-icon"><Icon size={16}/></div><div style={{flex:1}}><div style={{fontSize:13,fontWeight:800}}>{title}</div><div className="muted" style={{fontSize:11,lineHeight:1.6,marginTop:4}}>{description}</div></div><Toggle value={wallet.settings[key]} onChange={()=>change(key)} label={title}/></div>)}
      <button className="secondary-btn" onClick={()=>save()} style={{margin:'18px 0',minHeight:40,fontSize:11}} data-testid="button-save-preferences"><Check size={14}/>Save demo preferences</button>
    </section>
    <section className="panel" style={{padding:22,marginTop:15,borderColor:'rgba(196,136,106,.22)'}}><div style={{display:'flex',gap:13,alignItems:'flex-start'}}><CircleHelp size={17} color="#d3a078"/><div style={{flex:1}}><div style={{fontSize:12,fontWeight:800}}>Start over</div><p className="muted" style={{fontSize:11,lineHeight:1.7,margin:'5px 0 14px'}}>Clear this browser's demo wallet and return to the introduction. No real wallet exists to delete.</p><button className="secondary-btn" onClick={reset} style={{minHeight:38,fontSize:11}} data-testid="button-reset-demo"><X size={14}/>Reset demo</button></div></div></section>
  </div></Shell>;
}
function Router() {
  return <RoutedErrorBoundary><Switch>
    <Route path="/" component={Welcome}/>
    <Route path="/create-wallet" component={CreateWallet}/>
    <Route path="/dashboard" component={Dashboard}/>
    <Route path="/receive" component={Receive}/>
    <Route path="/send" component={Send}/>
    <Route path="/history" component={HistoryPage}/>
    <Route path="/security" component={Security}/>
    <Route component={NotFound}/>
  </Switch></RoutedErrorBoundary>;
}
function RoutedErrorBoundary({ children }: { children:ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}
function App() {
  const [storage]=useState<DemoStorage|null>(()=>{try{return window.localStorage;}catch{return null;}});
  const [wallet,setWallet]=useState<WalletData>(()=>storage
    ?loadDemoWallet(storage,defaults,sampleTransactions.map(({id})=>id),price)
    :defaults);
  const [persistenceWarning,setPersistenceWarning]=useState(!storage);
  const save=(nextWallet:WalletData=wallet)=>{
    if(!storage){setPersistenceWarning(true);return;}
    try{persistDemoWallet(storage,nextWallet);setPersistenceWarning(false);}
    catch{setPersistenceWarning(true);}
  };
  const reset=()=>{
    setWallet(defaults);
    if(!storage){setPersistenceWarning(true);return;}
    try{removeDemoWallet(storage);setPersistenceWarning(false);}
    catch{setPersistenceWarning(true);}
  };
  useEffect(()=>{
    if(!storage){setPersistenceWarning(true);return;}
    try{persistDemoWallet(storage,wallet);setPersistenceWarning(false);}
    catch{setPersistenceWarning(true);}
  },[wallet,storage]);
  const store=useMemo(()=>({wallet,setWallet,save,reset,persistenceWarning}),[wallet,persistenceWarning,storage]);
  return <QueryClientProvider client={queryClient}><TooltipProvider><Store.Provider value={store}><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/,'')}><Router/></WouterRouter></Store.Provider><Toaster/></TooltipProvider></QueryClientProvider>;
}

export default App;
