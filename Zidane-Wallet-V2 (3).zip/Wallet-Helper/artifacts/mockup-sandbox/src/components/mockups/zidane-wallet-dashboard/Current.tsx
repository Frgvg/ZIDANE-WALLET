import './_group.css';
import { ArrowDownLeft, ArrowRight, ArrowUpRight, Bitcoin, ChevronRight, History, LockKeyhole, ShieldCheck, Wallet } from 'lucide-react';

const transactions = [
  { id: 'tx-01', label: 'Demo deposit', direction: 'in', amount: '0.02500000', date: 'Today · 10:42 AM', status: 'Sample', recipient: 'Sample activity' },
  { id: 'tx-02', label: 'Coffee & company', direction: 'out', amount: '0.00180000', date: 'Yesterday · 2:18 PM', status: 'Sample', recipient: 'Demo recipient label' },
  { id: 'tx-03', label: 'Demo deposit', direction: 'in', amount: '0.06111000', date: 'May 18 · 9:06 AM', status: 'Sample', recipient: 'Sample activity' },
];

function TransactionList() {
  return <div>{transactions.map((tx) => <div className="transaction-row" key={tx.id}>
    <div className="tx-icon">{tx.direction === 'in' ? <ArrowDownLeft size={17}/> : <ArrowUpRight size={17}/>}</div>
    <div className="tx-grid">
      <div className="tx-label">{tx.label}</div>
      <div className="tx-amount" style={{ color: tx.direction === 'in' ? '#a8bd8f' : '#e1d8c4' }}>{tx.direction === 'in' ? '+' : '−'}{tx.amount} BTC</div>
      <div className="tx-date">{tx.date} · {tx.recipient}</div>
      <div className="tx-status">{tx.status}</div>
    </div>
  </div>)}</div>;
}

export function Current() {
  return <div className="wallet-shell">
    <header className="wallet-nav">
      <a href="#" className="brand"><span className="brand-mark">Z</span><span>ZIDANE <span style={{color:'#c9a85c'}}>WALLET</span></span></a>
      <nav className="nav-links" aria-label="Wallet navigation">
        {[['Wallet', Wallet], ['Receive', ArrowDownLeft], ['Send', ArrowUpRight], ['Activity', History], ['Security', LockKeyhole]].map(([label, Icon]) => {
          const NavIcon = Icon as typeof Wallet;
          return <a key={label as string} href="#" className={`nav-link ${label === 'Wallet' ? 'active' : ''}`}><span><NavIcon size={14} style={{display:'inline',verticalAlign:'-2px',marginRight:5}} /></span>{label as string}</a>;
        })}
      </nav>
      <span className="demo-chip">DEMO MODE</span>
    </header>
    <main className="content">
      <div className="notice"><ShieldCheck size={17} style={{flex:'none',marginTop:1}}/><div><b>Demo only.</b> All balances and activity on this screen are fictional sample data. Nothing here represents funds you own.</div></div>
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-end',margin:'28px 0 20px',gap:12}}>
        <div><div className="eyebrow">OVERVIEW</div><h1 className="page-title" style={{fontSize:38,marginBottom:0}}>Your wallet</h1></div>
        <span className="demo-chip">SAMPLE WALLET</span>
      </div>
      <section className="panel" style={{padding:'25px 28px',position:'relative',overflow:'hidden',marginBottom:17}}>
        <div style={{position:'absolute',right:-75,bottom:-160,width:280,height:280,borderRadius:'50%',border:'1px solid rgba(199,165,90,.18)'}}/>
        <div style={{position:'absolute',right:-45,bottom:-130,width:220,height:220,borderRadius:'50%',border:'1px solid rgba(199,165,90,.13)'}}/>
        <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}><span className="muted" style={{fontSize:12}}>Total balance <span className="eyebrow" style={{marginLeft:7,fontSize:9}}>DEMO</span></span><span className="mono muted" style={{fontSize:10}}>BTC / USD</span></div>
        <div className="serif" style={{fontSize:'clamp(35px,8vw,52px)',letterSpacing:'-.04em',marginTop:12}}>0.08431 <span style={{color:'#b4aa91',fontSize:'.58em'}}>BTC</span></div>
        <div className="mono muted" style={{fontSize:13,marginTop:5}}>≈ $5,659.73 USD <span style={{fontSize:9,color:'#817b6e'}}>SAMPLE ESTIMATE</span></div>
        <div style={{display:'flex',gap:10,marginTop:25,position:'relative'}}>
          <a href="#" className="primary-btn"><ArrowUpRight size={16}/>Send</a><a href="#" className="secondary-btn"><ArrowDownLeft size={16}/>Receive</a><a href="#" className="secondary-btn" aria-label="View all activity"><History size={16}/></a>
        </div>
      </section>
      <div className="dashboard-grid">
        <section className="panel" style={{padding:'20px 22px'}}>
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:5}}><h2 style={{fontSize:14,margin:0}}>Recent activity</h2><a href="#" className="eyebrow" style={{fontSize:9}}>VIEW ALL <ChevronRight size={12} style={{verticalAlign:'-3px'}}/></a></div>
          <TransactionList/>
        </section>
        <section className="panel" style={{padding:22,display:'flex',flexDirection:'column',justifyContent:'space-between',minHeight:225}}>
          <div><div className="tx-icon" style={{marginBottom:17}}><LockKeyhole size={17}/></div><div style={{fontSize:14,fontWeight:800}}>Learn without risk</div><p className="muted" style={{fontSize:11,lineHeight:1.7}}>This wallet is a safe walkthrough, not a place to hold real bitcoin.</p></div>
          <a href="#" className="secondary-btn" style={{width:'100%',minHeight:40,fontSize:11}}>Understand the demo <ArrowRight size={14}/></a>
        </section>
      </div>
    </main>
    <footer className="app-footer">A SAFE PLACE TO EXPLORE · NO REAL BITCOIN MOVES HERE</footer>
  </div>;
}
