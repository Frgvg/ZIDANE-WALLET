import './_group.css';
import { type MouseEvent, useState } from 'react';
import {
  ArrowDownLeft,
  ArrowRight,
  ArrowUpRight,
  Check,
  ChevronRight,
  CircleHelp,
  History,
  LockKeyhole,
  ShieldCheck,
  Wallet,
  X,
} from 'lucide-react';

type DemoAction = 'send' | 'receive' | null;
type Section = 'wallet' | 'receive' | 'send' | 'activity' | 'security';

const transactions = [
  {
    id: '01',
    label: 'Demo deposit',
    direction: 'in' as const,
    amount: '0.02500000',
    date: 'Today · 10:42 AM',
    detail: 'Sample activity',
  },
  {
    id: '02',
    label: 'Coffee & company',
    direction: 'out' as const,
    amount: '0.00180000',
    date: 'Yesterday · 2:18 PM',
    detail: 'Demo recipient label',
  },
  {
    id: '03',
    label: 'Demo deposit',
    direction: 'in' as const,
    amount: '0.06111000',
    date: 'May 18 · 9:06 AM',
    detail: 'Sample activity',
  },
];

const navItems: { label: string; section: Section; icon: typeof Wallet }[] = [
  { label: 'Wallet', section: 'wallet', icon: Wallet },
  { label: 'Receive', section: 'receive', icon: ArrowDownLeft },
  { label: 'Send', section: 'send', icon: ArrowUpRight },
  { label: 'Activity', section: 'activity', icon: History },
  { label: 'Security', section: 'security', icon: LockKeyhole },
];

const actionCopy = {
  send: {
    title: 'A safe send walkthrough',
    body: 'This demo never creates a transaction or connects to Bitcoin. Explore the idea of sending without entering an address or moving funds.',
    label: 'No transfer started',
  },
  receive: {
    title: 'A safe receive walkthrough',
    body: 'Real wallets can share a receive address. This learning wallet does not generate addresses or QR codes, and nothing can be deposited here.',
    label: 'No address generated',
  },
};

export function V2Dashboard() {
  const [activeSection, setActiveSection] = useState<Section>('wallet');
  const [activeAction, setActiveAction] = useState<DemoAction>(null);

  const goToSection = (event: MouseEvent<HTMLAnchorElement>, section: Section) => {
    if (section === 'send' || section === 'receive') {
      event.preventDefault();
      setActiveSection(section);
      setActiveAction(section);
      return;
    }
    setActiveSection(section);
    setActiveAction(null);
  };

  const openAction = (action: Exclude<DemoAction, null>) => {
    setActiveSection(action);
    setActiveAction(action);
  };

  return (
    <div className="zv2">
      <style>{`
        .zv2 {
          --zv-bg: #11110f;
          --zv-surface: #181815;
          --zv-surface-raised: #1d1c18;
          --zv-line: rgba(220, 202, 158, .12);
          --zv-line-strong: rgba(220, 202, 158, .2);
          --zv-text: #eee9dc;
          --zv-muted: #aaa496;
          --zv-subtle: #777367;
          --zv-gold: #c8a85f;
          --zv-gold-bright: #dfc47d;
          --zv-green: #aec29b;
          min-height: 100dvh;
          color: var(--zv-text);
          background:
            radial-gradient(ellipse at 76% -17%, rgba(182, 143, 63, .12), transparent 38%),
            var(--zv-bg);
          font-family: var(--app-font-sans);
          isolation: isolate;
        }
        .zv2 * { box-sizing: border-box; }
        .zv2 a { color: inherit; text-decoration: none; }
        .zv2 button { font: inherit; color: inherit; -webkit-tap-highlight-color: transparent; }
        .zv2 button:focus-visible, .zv2 a:focus-visible {
          outline: 2px solid var(--zv-gold-bright);
          outline-offset: 3px;
        }
        .zv2-topbar {
          width: min(100% - 64px, 1216px);
          margin: 0 auto;
          min-height: 82px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 24px;
          border-bottom: 1px solid rgba(220, 202, 158, .1);
        }
        .zv2-brand {
          display: inline-flex;
          align-items: center;
          gap: 12px;
          flex: none;
          font-size: 12px;
          font-weight: 800;
          letter-spacing: .17em;
        }
        .zv2-mark {
          display: grid;
          place-items: center;
          width: 35px;
          height: 35px;
          border: 1px solid rgba(18, 16, 11, .4);
          border-radius: 50%;
          color: #1a170f;
          background: linear-gradient(145deg, #dfc47b, #b79148);
          font: 600 19px/1 var(--app-font-serif);
          box-shadow: inset 0 1px 0 rgba(255,255,255,.36), 0 5px 20px rgba(187,147,60,.12);
        }
        .zv2-brand-name span { color: var(--zv-gold-bright); }
        .zv2-nav {
          display: flex;
          align-items: center;
          gap: 3px;
          margin-left: auto;
          margin-right: auto;
        }
        .zv2-nav-link {
          min-height: 39px;
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 0 13px;
          border: 1px solid transparent;
          border-radius: 9px;
          color: #a7a294;
          font-size: 12px;
          transition: color .18s ease, background .18s ease, border-color .18s ease;
        }
        .zv2-nav-link:hover { color: var(--zv-text); background: rgba(255,255,255,.035); }
        .zv2-nav-link.is-active {
          color: var(--zv-gold-bright);
          background: rgba(197, 161, 82, .085);
          border-color: rgba(197, 161, 82, .15);
        }
        .zv2-demo-pill {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 8px 11px;
          border: 1px solid rgba(208, 173, 95, .28);
          border-radius: 999px;
          color: #d7bd79;
          font: 9px var(--app-font-mono);
          letter-spacing: .14em;
          white-space: nowrap;
        }
        .zv2-demo-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: var(--zv-gold);
          box-shadow: 0 0 0 3px rgba(200,168,95,.1);
        }
        .zv2-main {
          width: min(100% - 64px, 1040px);
          margin: 0 auto;
          padding: 46px 0 68px;
        }
        .zv2-notice {
          display: flex;
          align-items: center;
          gap: 13px;
          padding: 14px 17px;
          border: 1px solid rgba(208, 173, 95, .22);
          border-radius: 11px;
          background: linear-gradient(100deg, rgba(184,145,62,.1), rgba(184,145,62,.035));
          color: #cfc096;
          font-size: 11px;
          line-height: 1.55;
        }
        .zv2-notice-icon {
          width: 31px;
          height: 31px;
          flex: none;
          display: grid;
          place-items: center;
          border-radius: 9px;
          color: var(--zv-gold-bright);
          background: rgba(201, 164, 84, .1);
        }
        .zv2-notice strong { color: #ead9a7; font-weight: 700; }
        .zv2-heading-row {
          display: flex;
          align-items: flex-end;
          justify-content: space-between;
          gap: 18px;
          margin: 37px 0 19px;
        }
        .zv2-kicker {
          color: var(--zv-gold);
          font: 9px var(--app-font-mono);
          letter-spacing: .2em;
          text-transform: uppercase;
        }
        .zv2-title {
          margin: 8px 0 0;
          font: 500 clamp(32px, 5vw, 43px)/1.08 var(--app-font-serif);
          letter-spacing: -.035em;
        }
        .zv2-heading-aside {
          color: var(--zv-subtle);
          font: 10px var(--app-font-mono);
          letter-spacing: .05em;
          padding-bottom: 5px;
        }
        .zv2-balance {
          position: relative;
          overflow: hidden;
          padding: 27px 31px 25px;
          border: 1px solid rgba(218, 194, 139, .19);
          border-radius: 17px;
          background:
            linear-gradient(105deg, rgba(34,32,26,.98), rgba(25,24,20,.98) 62%, rgba(31,29,23,.98)),
            var(--zv-surface);
          box-shadow: 0 18px 54px rgba(0,0,0,.2), inset 0 1px 0 rgba(255,255,255,.025);
        }
        .zv2-balance::before, .zv2-balance::after {
          content: '';
          position: absolute;
          pointer-events: none;
          border: 1px solid rgba(204, 169, 94, .13);
          border-radius: 50%;
        }
        .zv2-balance::before { width: 360px; height: 360px; right: -106px; top: -221px; }
        .zv2-balance::after { width: 270px; height: 270px; right: -61px; top: -178px; border-color: rgba(204, 169, 94, .085); }
        .zv2-balance-top, .zv2-balance-lower { position: relative; z-index: 1; }
        .zv2-balance-top {
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 14px;
        }
        .zv2-balance-label {
          display: flex;
          align-items: center;
          gap: 9px;
          color: #c6c0b2;
          font-size: 12px;
        }
        .zv2-tag {
          padding: 4px 6px;
          border: 1px solid rgba(206,174,105,.23);
          border-radius: 4px;
          color: #d7bb70;
          font: 8px var(--app-font-mono);
          letter-spacing: .12em;
        }
        .zv2-currency {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          color: #9c9689;
          font: 9px var(--app-font-mono);
          letter-spacing: .11em;
        }
        .zv2-balance-value {
          margin-top: 14px;
          font: 500 clamp(39px, 7vw, 58px)/1.05 var(--app-font-serif);
          letter-spacing: -.045em;
          color: #f0e9d7;
        }
        .zv2-balance-value span { color: #b7aa8a; font-size: .54em; letter-spacing: -.01em; }
        .zv2-fiat-line {
          margin-top: 8px;
          color: #aaa394;
          font: 12px var(--app-font-mono);
        }
        .zv2-fiat-line small {
          margin-left: 7px;
          color: #817b6e;
          font-size: 8px;
          letter-spacing: .1em;
        }
        .zv2-balance-lower {
          display: flex;
          align-items: flex-end;
          justify-content: space-between;
          gap: 22px;
          margin-top: 25px;
        }
        .zv2-actions { display: flex; flex-wrap: wrap; gap: 9px; }
        .zv2-button {
          min-height: 42px;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 9px;
          padding: 0 16px;
          border: 1px solid #494336;
          border-radius: 8px;
          background: rgba(255,255,255,.025);
          color: #e5decd;
          font-size: 11px;
          font-weight: 700;
          cursor: pointer;
          transition: transform .18s ease, background .18s ease, border-color .18s ease;
        }
        .zv2-button:hover { transform: translateY(-1px); border-color: rgba(218,194,139,.42); background: rgba(255,255,255,.055); }
        .zv2-button-primary {
          border-color: #d5b763;
          background: linear-gradient(135deg, #d8bb70, #b9944b);
          color: #1a170f;
          box-shadow: inset 0 1px 0 rgba(255,255,255,.28), 0 5px 18px rgba(178,137,52,.13);
        }
        .zv2-button-primary:hover { background: linear-gradient(135deg, #e1c87f, #c2a055); border-color: #e1c87f; }
        .zv2-balance-footnote {
          display: flex;
          align-items: center;
          gap: 7px;
          padding-bottom: 2px;
          color: #8e897d;
          font: 9px var(--app-font-mono);
          letter-spacing: .015em;
          text-align: right;
        }
        .zv2-balance-footnote svg { color: var(--zv-gold); }
        .zv2-action-info {
          display: flex;
          align-items: flex-start;
          gap: 13px;
          padding: 17px 18px;
          margin-top: 13px;
          border: 1px solid rgba(208,173,95,.2);
          border-radius: 11px;
          background: rgba(197,161,82,.055);
          animation: zv2-enter .22s ease both;
        }
        @keyframes zv2-enter { from { opacity: 0; transform: translateY(5px); } to { opacity: 1; transform: translateY(0); } }
        .zv2-action-check {
          width: 29px;
          height: 29px;
          flex: none;
          display: grid;
          place-items: center;
          border-radius: 50%;
          border: 1px solid rgba(174,194,155,.28);
          color: var(--zv-green);
          background: rgba(174,194,155,.08);
        }
        .zv2-action-copy { min-width: 0; flex: 1; }
        .zv2-action-title { margin: 0; color: #e6dcc0; font-size: 12px; font-weight: 700; }
        .zv2-action-text { margin: 5px 0 0; color: #a9a292; font-size: 10px; line-height: 1.65; }
        .zv2-action-state {
          display: inline-block;
          margin-top: 8px;
          color: #bac5a8;
          font: 8px var(--app-font-mono);
          letter-spacing: .1em;
          text-transform: uppercase;
        }
        .zv2-close {
          flex: none;
          width: 28px;
          height: 28px;
          display: grid;
          place-items: center;
          border: 1px solid transparent;
          border-radius: 7px;
          color: #938d7e;
          background: transparent;
          cursor: pointer;
        }
        .zv2-close:hover { border-color: var(--zv-line); color: var(--zv-text); }
        .zv2-grid {
          display: grid;
          grid-template-columns: minmax(0, 1.48fr) minmax(230px, .72fr);
          align-items: stretch;
          gap: 14px;
          margin-top: 15px;
        }
        .zv2-panel {
          min-width: 0;
          border: 1px solid var(--zv-line);
          border-radius: 13px;
          background: linear-gradient(140deg, rgba(255,255,255,.035), rgba(255,255,255,.013));
        }
        .zv2-activity { padding: 19px 21px 7px; }
        .zv2-panel-head {
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 16px;
          margin-bottom: 5px;
        }
        .zv2-panel-title { margin: 0; color: #e9e3d5; font-size: 13px; font-weight: 700; }
        .zv2-link {
          display: inline-flex;
          align-items: center;
          gap: 4px;
          color: #c7aa63;
          font: 8px var(--app-font-mono);
          letter-spacing: .11em;
          white-space: nowrap;
          transition: color .18s ease;
        }
        .zv2-link:hover { color: #ecd48e; }
        .zv2-row {
          display: flex;
          align-items: center;
          gap: 12px;
          min-height: 67px;
          border-bottom: 1px solid rgba(220,202,158,.075);
        }
        .zv2-row:last-child { border-bottom: 0; }
        .zv2-tx-icon {
          width: 35px;
          height: 35px;
          flex: none;
          display: grid;
          place-items: center;
          border: 1px solid rgba(208,173,95,.18);
          border-radius: 10px;
          color: #d1b568;
          background: rgba(208,173,95,.065);
        }
        .zv2-tx-main { min-width: 0; flex: 1; }
        .zv2-tx-title { overflow: hidden; color: #e0dacb; font-size: 11px; font-weight: 700; text-overflow: ellipsis; white-space: nowrap; }
        .zv2-tx-detail { overflow: hidden; margin-top: 4px; color: #878275; font: 8px var(--app-font-mono); text-overflow: ellipsis; white-space: nowrap; }
        .zv2-tx-right { flex: none; text-align: right; }
        .zv2-tx-amount { color: #ddd6c6; font: 10px var(--app-font-mono); }
        .zv2-tx-amount.is-in { color: var(--zv-green); }
        .zv2-tx-status { display: inline-flex; align-items: center; gap: 4px; margin-top: 5px; color: #9ead8c; font-size: 8px; }
        .zv2-security {
          display: flex;
          flex-direction: column;
          justify-content: space-between;
          padding: 20px;
        }
        .zv2-security-icon {
          width: 36px;
          height: 36px;
          display: grid;
          place-items: center;
          margin-bottom: 16px;
          border: 1px solid rgba(208,173,95,.19);
          border-radius: 11px;
          color: var(--zv-gold-bright);
          background: rgba(208,173,95,.07);
        }
        .zv2-security h2 { margin: 0; color: #e9e2d3; font-size: 13px; }
        .zv2-security p { margin: 8px 0 16px; color: #9f998b; font-size: 10px; line-height: 1.7; }
        .zv2-security-points { display: grid; gap: 9px; margin: 0 0 17px; padding: 0; list-style: none; }
        .zv2-security-points li { display: flex; align-items: center; gap: 8px; color: #b1aa99; font-size: 9px; }
        .zv2-security-points svg { color: #aebe99; flex: none; }
        .zv2-security-link {
          min-height: 37px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 8px;
          padding: 0 11px;
          border: 1px solid rgba(220,202,158,.16);
          border-radius: 8px;
          color: #d9d1bf;
          background: rgba(255,255,255,.018);
          font-size: 9px;
          font-weight: 700;
          transition: border-color .18s ease, background .18s ease;
        }
        .zv2-security-link:hover { border-color: rgba(218,194,139,.4); background: rgba(255,255,255,.045); }
        .zv2-footer {
          width: min(100% - 64px, 1040px);
          margin: 0 auto;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 16px;
          padding: 19px 0 25px;
          border-top: 1px solid rgba(220,202,158,.085);
          color: #716d63;
          font: 8px var(--app-font-mono);
          letter-spacing: .11em;
        }
        .zv2-footer-note { display: inline-flex; align-items: center; gap: 7px; color: #8a8477; }
        .zv2-footer-note svg { color: #a58e55; }
        @media (max-width: 820px) {
          .zv2-topbar { width: min(100% - 40px, 700px); min-height: 74px; flex-wrap: wrap; }
          .zv2-nav { order: 3; width: 100%; justify-content: center; margin: -4px 0 11px; }
          .zv2-main, .zv2-footer { width: min(100% - 40px, 700px); }
          .zv2-main { padding-top: 32px; }
          .zv2-grid { grid-template-columns: 1fr; }
          .zv2-security { min-height: 0; }
        }
        @media (max-width: 560px) {
          .zv2-topbar { width: calc(100% - 32px); min-height: 69px; gap: 10px; }
          .zv2-brand { gap: 9px; font-size: 10px; }
          .zv2-mark { width: 31px; height: 31px; font-size: 17px; }
          .zv2-demo-pill { padding: 7px 8px; font-size: 8px; }
          .zv2-nav {
            position: sticky;
            top: 0;
            z-index: 5;
            width: calc(100% + 32px);
            margin: 0 -16px;
            padding: 7px 10px;
            justify-content: space-between;
            border-top: 1px solid rgba(220,202,158,.08);
            border-bottom: 1px solid rgba(220,202,158,.08);
            background: rgba(17,17,15,.94);
            backdrop-filter: blur(14px);
          }
          .zv2-nav-link { min-height: 42px; flex: 1; flex-direction: column; justify-content: center; gap: 3px; padding: 4px 2px; font-size: 8px; }
          .zv2-main, .zv2-footer { width: calc(100% - 32px); }
          .zv2-main { padding: 23px 0 39px; }
          .zv2-notice { align-items: flex-start; padding: 12px; font-size: 10px; }
          .zv2-notice-icon { width: 28px; height: 28px; }
          .zv2-heading-row { margin: 27px 0 15px; }
          .zv2-title { font-size: 35px; }
          .zv2-heading-aside { display: none; }
          .zv2-balance { padding: 21px 18px 19px; border-radius: 14px; }
          .zv2-balance-value { font-size: clamp(38px, 10vw, 49px); }
          .zv2-balance-lower { display: block; margin-top: 21px; }
          .zv2-actions { display: grid; grid-template-columns: 1fr 1fr; }
          .zv2-button { min-height: 43px; padding: 0 10px; }
          .zv2-balance-footnote { margin-top: 14px; text-align: left; }
          .zv2-action-info { padding: 13px 12px; }
          .zv2-action-text { font-size: 9px; }
          .zv2-activity { padding: 16px 14px 6px; }
          .zv2-panel-head { margin-bottom: 3px; }
          .zv2-row { gap: 9px; min-height: 64px; }
          .zv2-tx-icon { width: 31px; height: 31px; }
          .zv2-tx-title { font-size: 10px; }
          .zv2-tx-detail { font-size: 7px; }
          .zv2-tx-amount { font-size: 9px; }
          .zv2-security { padding: 17px; }
          .zv2-footer { flex-direction: column; align-items: flex-start; padding-bottom: 20px; font-size: 7px; }
        }
        @media (prefers-reduced-motion: reduce) {
          .zv2 *, .zv2 *::before, .zv2 *::after { animation-duration: .01ms !important; animation-iteration-count: 1 !important; scroll-behavior: auto !important; transition-duration: .01ms !important; }
        }
      `}</style>

      <header className="zv2-topbar">
        <a className="zv2-brand" href="#wallet" onClick={(event) => goToSection(event, 'wallet')} aria-label="Zidane Wallet, demo home">
          <span className="zv2-mark">Z</span>
          <span className="zv2-brand-name">ZIDANE <span>WALLET</span></span>
        </a>
        <nav className="zv2-nav" aria-label="Wallet navigation">
          {navItems.map(({ label, section, icon: Icon }) => (
            <a
              key={section}
              href={`#${section}`}
              className={`zv2-nav-link ${activeSection === section ? 'is-active' : ''}`}
              aria-current={activeSection === section ? 'page' : undefined}
              onClick={(event) => goToSection(event, section)}
            >
              <Icon size={14} strokeWidth={1.8} aria-hidden="true" />
              <span>{label}</span>
            </a>
          ))}
        </nav>
        <span className="zv2-demo-pill"><span className="zv2-demo-dot" /> LOCAL DEMO</span>
      </header>

      <main className="zv2-main" id="wallet">
        <div className="zv2-notice" role="note">
          <span className="zv2-notice-icon"><ShieldCheck size={16} strokeWidth={1.8} /></span>
          <span><strong>Learning wallet — not real Bitcoin.</strong> Every balance and activity item is fictional sample data. Nothing here represents funds you own.</span>
        </div>

        <div className="zv2-heading-row">
          <div>
            <div className="zv2-kicker">Your private learning space</div>
            <h1 className="zv2-title">Your wallet</h1>
          </div>
          <div className="zv2-heading-aside">WALLET 01 <span style={{ color: '#5b574d' }}> / </span> SAMPLE</div>
        </div>

        <section className="zv2-balance" aria-labelledby="zv2-balance-title">
          <div className="zv2-balance-top">
            <div className="zv2-balance-label" id="zv2-balance-title">Total balance <span className="zv2-tag">SAMPLE</span></div>
            <div className="zv2-currency"><span>BTC</span><span style={{ color: '#615d52' }}>/</span><span>USD</span></div>
          </div>
          <div className="zv2-balance-value">0.08431 <span>BTC</span></div>
          <div className="zv2-fiat-line">≈ $5,659.73 USD <small>SAMPLE ESTIMATE</small></div>
          <div className="zv2-balance-lower">
            <div className="zv2-actions">
              <button className="zv2-button zv2-button-primary" type="button" onClick={() => openAction('send')}>
                <ArrowUpRight size={15} /> Send
              </button>
              <button className="zv2-button" type="button" onClick={() => openAction('receive')}>
                <ArrowDownLeft size={15} /> Receive
              </button>
              <a className="zv2-button" href="#activity" onClick={(event) => goToSection(event, 'activity')} aria-label="View activity">
                <History size={15} /> Activity
              </a>
            </div>
            <div className="zv2-balance-footnote"><LockKeyhole size={12} /> No network connection · No real funds</div>
          </div>
        </section>

        {activeAction && (
          <aside className="zv2-action-info" aria-live="polite">
            <span className="zv2-action-check"><Check size={14} /></span>
            <div className="zv2-action-copy">
              <h2 className="zv2-action-title">{actionCopy[activeAction].title}</h2>
              <p className="zv2-action-text">{actionCopy[activeAction].body}</p>
              <span className="zv2-action-state">{actionCopy[activeAction].label}</span>
            </div>
            <button className="zv2-close" type="button" onClick={() => { setActiveAction(null); setActiveSection('wallet'); }} aria-label="Close demo explanation">
              <X size={15} />
            </button>
          </aside>
        )}

        <div className="zv2-grid">
          <section className="zv2-panel zv2-activity" id="activity" aria-labelledby="zv2-activity-title">
            <div className="zv2-panel-head">
              <h2 className="zv2-panel-title" id="zv2-activity-title">Recent activity</h2>
              <a className="zv2-link" href="#activity" onClick={(event) => goToSection(event, 'activity')}>VIEW ALL <ChevronRight size={12} /></a>
            </div>
            <div>
              {transactions.map((transaction) => {
                const isIncoming = transaction.direction === 'in';
                const TransactionIcon = isIncoming ? ArrowDownLeft : ArrowUpRight;
                return (
                  <div className="zv2-row" key={transaction.id}>
                    <span className="zv2-tx-icon"><TransactionIcon size={16} strokeWidth={1.8} /></span>
                    <div className="zv2-tx-main">
                      <div className="zv2-tx-title">{transaction.label}</div>
                      <div className="zv2-tx-detail">{transaction.date} · {transaction.detail}</div>
                    </div>
                    <div className="zv2-tx-right">
                      <div className={`zv2-tx-amount ${isIncoming ? 'is-in' : ''}`}>{isIncoming ? '+' : '−'}{transaction.amount} BTC</div>
                      <div className="zv2-tx-status"><Check size={10} /> Sample</div>
                    </div>
                  </div>
                );
              })}
            </div>
          </section>

          <section className="zv2-panel zv2-security" id="security" aria-labelledby="zv2-security-title">
            <div>
              <div className="zv2-security-icon"><LockKeyhole size={17} strokeWidth={1.7} /></div>
              <h2 id="zv2-security-title">Learn without risk</h2>
              <p>A calm place to get familiar with wallet screens, before you ever use a real wallet.</p>
              <ul className="zv2-security-points">
                <li><Check size={12} /> Stored only in this demo</li>
                <li><Check size={12} /> No addresses or keys</li>
                <li><Check size={12} /> No Bitcoin transactions</li>
              </ul>
            </div>
            <a className="zv2-security-link" href="#security" onClick={(event) => goToSection(event, 'security')}>
              <span>How this demo stays safe</span><ArrowRight size={14} />
            </a>
          </section>
        </div>
      </main>

      <footer className="zv2-footer">
        <span className="zv2-footer-note"><CircleHelp size={12} /> A practice space, not a Bitcoin wallet.</span>
        <span>NO NETWORK · NO REAL FUNDS · FOR LEARNING ONLY</span>
      </footer>
    </div>
  );
}
