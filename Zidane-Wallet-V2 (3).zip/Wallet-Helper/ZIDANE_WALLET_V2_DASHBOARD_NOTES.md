# Zidane Wallet V2 — Dashboard

This working copy contains the first completed V2 dashboard update, based on the approved design:

- Graphite dashboard background.
- Hybrid portfolio summary showing sample USD and BTC values.
- Local hide/show balance control with state-aware icon and accessible label.
- Summary cards for transaction count, received entries, and sent entries.
- Dashboard safety banner and security-center card.
- Recent activity remains connected to the existing local demo history.
- Existing seven routes, fixed mobile navigation, and responsive layouts are retained.

## Safety boundary

This remains a demo-only wallet interface. It does not create private keys, real Bitcoin addresses, connect to a blockchain, or broadcast transactions. All portfolio figures and activity are fictional sample data. No real funds can be received or sent.

## Verification

- Automated tests: 21 passed, 0 failed.
- TypeScript/JSX transpilation syntax check: passed for the main app and core wallet modules.
- `git diff --check`: passed.
- Full TypeScript typecheck and production build: not run. The archive environment has no installed project dependencies or `pnpm`, and package-manager download was unavailable. Run `pnpm install`, then `pnpm --filter @workspace/zidane-wallet typecheck` and `pnpm --filter @workspace/zidane-wallet build` in Replit or another supported environment.

The original uploaded `Wallet-Helper.zip` remains unchanged. This is a separate V2 working copy.
